import {PerspectiveCamera,Vector3} from 'three';

// Optional game-owned views. No target survives leaving this mode.
export function gameRenderViews(definitions,aspect,cache=new Map(),shake){
  if(definitions==null){cache.clear();return [];}
  if(!Array.isArray(definitions)||definitions.length>3)throw Error('Render views must contain at most three cameras');
  const used=new Set(),vector=(value,n)=>Array.isArray(value)&&value.length===n&&value.every(Number.isFinite);
  const views=definitions.map((view,index)=>{
    if(!vector(view.eye,3)||!vector(view.target,3)||!Number.isFinite(view.fov)||view.fov<10||view.fov>120)throw Error('Render view camera invalid');
    const polygon=view.polygon;
    if(!Array.isArray(polygon)||polygon.length<3||polygon.length>8||polygon.some(p=>!vector(p,2)||p.some(v=>v<0||v>1)))throw Error('Render view polygon invalid');
    let sign=0;for(let i=0;i<polygon.length;i++){const a=polygon[i],b=polygon[(i+1)%polygon.length],c=polygon[(i+2)%polygon.length],cross=(b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0]);if(Math.abs(cross)>1e-8){if(sign&&Math.sign(cross)!==sign)throw Error('Render view polygon must be convex');sign=Math.sign(cross);}}if(!sign)throw Error('Render view polygon has no area');
    const eye=new Vector3(...view.eye),target=new Vector3(...view.target);if(eye.distanceToSquared(target)<1e-8)throw Error('Render view target equals eye');
    const camera=cache.get(index)||new PerspectiveCamera();cache.set(index,camera);used.add(index);camera.position.copy(eye);camera.up.set(0,1,0);camera.fov=view.fov;camera.aspect=aspect;camera.near=.05;camera.far=100000;camera.lookAt(target);camera.clearViewOffset();if(view.focus){if(!vector(view.focus,2)||view.focus.some(v=>v<0||v>1))throw Error("Render view focus invalid");camera.setViewOffset(1,1,.5-view.focus[0],.5-view.focus[1],1,1);}camera.updateProjectionMatrix();if(shake?.remaining>0){const t=shake.duration-shake.remaining,a=shake.intensity*shake.remaining/Math.max(.001,shake.duration);camera.position.x+=Math.sin(t*73.9)*a;camera.position.y+=Math.cos(t*91.7)*a;}camera.updateMatrixWorld(true);
    return {camera,polygon};
  });
  for(const key of cache.keys())if(!used.has(key))cache.delete(key);return views;
}
