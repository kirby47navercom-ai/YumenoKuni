## WORK3416 해결·설치 근거
긴 PE 경로의 선행 filesystem/EndUpdateResource와 worker spawn을 독립 반증했어요. 최종 기본/298자 PE·공용8·실제 release40frame/OS입력/C++목록·설치17owner/PE 해시 통과. DLL 원인 가설은 철회했고 실패한 경로와 fixture 수정은 성과로 세지 않아요. USER_INSTALL3417·ENGINE_WORK3416에 확정 근거를 연결했어요.

# 3416 네이티브 패키징 긴 경로 재현

깊게 둔 격리 검사에서 stamp-game helper 두 번60초 대기. 입력/목록 JS7개는 통과. XInput 지연 로딩으로도 같은 경로에서 재현돼 DLL 원인 가설은 철회. 대상 PE 절대 경로263문자. 다음 반증: 같은 owned PE의 BeginUpdateResource 일반경로/extended경로와 short경로를 직접 비교하고 실제 helper 오류를 무인으로 반환하도록 좁혀요. 전체 native 패키지 검사를 원인 불명 상태로 다시 반복하지 않아요. 실패는 구현 성과 아님.

# 2938 다중 이미터 정렬 fixture

새 검사에서 age 정렬 이름에 기존 Renderer 검증과 반대인 기대 순서를 가정했어요. 기존 검증의 정렬 규약을 확인하고, 이 검사의 목적에 맞게 depth/depthReverse의 서로 반대 순서를 두 컴포넌트에서 독립 대조하도록 고쳤어요. 공용 정렬 알고리즘이나 셰이더를 바꾸지 않았어요. 실패 fixture는 통과 수에 넣지 않아요. 최종 multi-emitter-mEKtPF는 12개 통과이며 나머지 영향 검사·C++ 바이너리는 같은 실행의 통과 근거를 재사용해요.

# 2895–2907 지면·미리보기·질량 브러시

첫 부모 회전 fixture의 지면 목표는 길이를 유지한 다리의 도달 범위 밖이었어요. 도달 가능한 사례와 불가능한 사례를 나누고 후자는 정확한 길이·잔여 오차를 검증해요. 첫 바닥 fixture는 BoxCollider의 실제 extent 대신 size를 사용했어요. -1/1/4 마스크 직접 질의와 공용 기본값을 대조해 fixture를 고쳤고 물리 구현을 맞춰 바꾸지 않았어요.
검토에서 구형 오브젝트의 objectComponents가 원본 components를 채우는 경로를 찾아 defaultsForObject의 반환값만 읽도록 고쳤어요. parentId 우선순위·타일 콜라이더 보존·None 필터와 재생 중 비활성화되는 브러시 소유자를 추가 대조해요.
질의 전용 모드는 물리 sensor를 사용하므로 isSensor만 보면 트리거가 아닌 표면도 빠졌어요. authored trigger를 기준으로 공용 predicate를 고치고 2D/3D 7종 질의·실제 트리거·immutable native adapter를 대조해요. 최종 소유 보고서는 ENGINE_WORK_2920에 연결해요. 실패한 초기 fixture와 읽기 전용 심볼 탐색 실패는 구현/검사 통과 수에 넣지 않아요.

# 2882 짧은 조회 검사

첫 fixture는 async engineContext의 거절을 assert.throws로 검사해 unhandled rejection을 만들었어요. assert.rejects로 수정했어요. 다음 미등록 fixture의 task에 context가 들어 있어 기존 등록경로가 선택됐으므로 focused-miss가 맞았어요. 무관한 문자열과 등록경로 miss를 별도 사례로 분리했어요. 엔진의 fail-closed 검색을 약화하지 않아요. 최종6개 context-compact-HxpIIG 통과.
기존1058gate도 reflectionProbeMeshBounds 소유자가 이전 HEAD에 미등록이라 실패했어요. ENGINE_STATUS에 이미 명시된 reflection-probe-bounds.js를 정확 경로로 등록해 한 파일에서 실제 선언을 확인했고, 기존gate가 통과했어요(ai-context-2885-legacy.json). --all/자동 fallback은 사용하지 않았어요.

# 2841 소유 C++ 검사 문서

첫 C++ 실행은 픽셀용 소유 document가 addEventListener를 제공하지 않아 engineOperations 초기화에서 실패했어요. 엔진을 바꾸지 않고 이미지 fixture에 add/removeEventListener 표면을 추가했어요. 같은 C++/SDK 캐시로 실제3메서드·9호출·9쓰기와 세 종류 밉/최종0 lease가 통과했어요(layered-disk-cpp-MjTmtg). 실패한 초기화를 성과로 계산하지 않아요.

분포2824 첫 묶음: 실제 particleMass 비율이1로남음. 설치 Rapier descriptor를독립확인: setMass(2).setMasses([1.6,.4]) 후에도 mass=2 유지·uniform total 우선. 공개 descriptor.mass=null 뒤 정규화 masses 사용하도록수정. 인장전용 복원 검사의 signed X는 자유끝이원점을지날수있으므로 제약인 실제거리로수정. native솔버를대체하지않음. 첫실패는성과미포함; 최종acceptance는WORK2830에기록.

# 2807 C++ 발 고정 검사 응답 해석

현상: Plant 통과 뒤 Release의 reply.objects에서 Rig를 찾지 못해 검사 TypeError. group2805와 foot-plant-cpp-ySx3vh/Plant-reply.json 근거. 같은 필드를 로깅한 재실행도 종료 오류를 재현했으므로 엔진을 추측 수정하지 않아요.
근거: 첫 응답은 nativeProperties.seen=true의 변경분만 반환해요. 검사가 VM의 seen=false에 이 변경을 반영하지 않아 Release의 seen=false는 변경 없음으로 생략돼요. objects는 전체 스냅샷이 아니라 변경분이에요.
다음 반증: 동일 헤더/source/SDK 캐시 worker를 사용하고, 반환된 probe 속성 변경분을 VM에 반영한 뒤 두 호출의 Bool 결과·공용 명령·실제 foot state를 확인해요. finally에서 Promise를 반환하는 host.close()도 await해요. 새 소스/SDK 재컴파일·renderer 검사는 필요 없어요.
확정: foot-plant-cpp-3GmwLg에서 같은 소스/SDK 캐시로 Set/GetBool2회·공용명령·실제 foot lock/release 통과. 신규 production native 수정 없음.
금지: reply.objects가 매번 모든 액터를 포함한다고 가정하거나 native 반환 정책을 이 검사에 맞춰 바꾸지 않아요.

# 현재 진단 — 렌더링 지연과 거리장 LOD

## 1951 극단 시간 키의 유한성

일반 UI/CPP/D3D 설치 후보69151e44930c50cb 통과 뒤 추가 수치 반증에서 [(0,0),(1e-310,1)]이 유효 판정을 받지만 sample(1)=Infinity가 됐어요. 키값 자체의 finite 검사만으로 충분하지 않았어요. 모든 구간의 유한 기울기와 지원 시간86400초/최대배율100에서 양끝 연장의 유한성을 함께 검사해요. 간격이 좁아도 기울기가 정상인 (1e-300,1e-300)은 허용해 일괄 최소간격 제한을 넣지 않아요. 이 후보의 기존 통과를 극단 입력 검증까지 완료로 세지 않으며 guard를 반영한 최종 설치를 별도로 확정해요.

## 1947 시간 리매핑 경계 검사

첫 unit은 0.1을 반복 누적한 뒤 0.45를 더해 3.25 경계가 정확하다고 가정했어요. 실제 누적이 경계를 조금 넘어 Zero 이벤트도 발생했으므로 fixture를 이진수로 정확한 0.125/0.25 간격으로 바꿔 End와 다음 tick의 Zero를 독립 대조해요. 엔진 이벤트를 지우거나 epsilon으로 실제 경계 통과를 숨기지 않아요.

## 1943 활성 문서의 숨겨진 제작 창

설치 캡처가 일반 뷰포트를 보여 원본 표시 API 상태와 실제 보이는 미리보기가 다름을 발견했어요. fixture에서 document.open 후 시간 입력 hit-test를 추가했지만 VFjdTZ에서도 timeout했어요. editor.state는 activeDocument=시퀀스인데 focusedWindow=scene이고, app.js activateDocument는 같은 경로이면 renderInspector 뒤 바로 반환해요. startPlay는 dock.open(scene)을 사용하므로 문서는 같아도 활성 dock 탭은 달라질 수 있어요. 가설: 같은 문서 재선택에서 실제 소유 pane이 숨겨진 경우 dock.open으로 올려야 해요. 최소 반증은 같은 fixture의 document.open 뒤 시간 입력 hit-test/보이는 시퀀스 캡처이며, 보이는 pane의 편집 상태를 재설치하거나 전체 layout을 초기화하지 않아요. 검사 timeout을 기능 성공으로 세지 않아요.

## 1938 C++ 같은 콜백의 명시 ID 교체

다음 SiPvqM 창은 sphere 복사본을 실제로 만들었지만 검사에서 새 프리팹 루트의 이름을 기존 이름 Existing3D로 가정해 timeout했어요. failure.state에는 같은 소유 ID의 name=root/kind=sphere가 있어요. 비교 대상을 첫 복사본의 안정된 ID로 고치며, 표시 이름을 바꾸거나 엔진 템플릿 재생을 우회하지 않아요. 원본 이름과 새 프리팹 이름이 다를 수 있음을 그대로 검증해요.

첫 실제창 fGyeae에서 `LifetimeProbe::Replace`가 Destroy(Existing3D)와 같은ID의 비풀 Spawn을 한 콜백에 연달아 호출해 `Spawn.hpp:24 spawn actor id already exists`로 거절됐어요. native bridge는 Destroy 뒤 로컬 상태를 destroying으로 표시하고 Spawn은 같은 에셋의 비활성 풀만 재사용해요. 이 제한을 단순 조건 제거로 풀면 활성 C++ 인스턴스/셀 세대 정리와 충돌할 수 있어 임의 우회하지 않아요. 실제창은 기존 API가 허용하는 삭제 완료 관찰 후 C++ Spawn으로 재생성을 검사하며, 연속 활성 ID교체 캡처 자체는 1937 독립 VM 검사로 구분해요. 같은 콜백의 원자적 ID교체/세대 관리는 CPP-01 잔여에 남겨요. 창 실패를 기능 완성이나 실행 성공으로 세지 않아요.

## 1931 검사 fixture 수정

1933 추가 경계 반증: auto 값0@2,1@2.000001,2@2.2·상수 infinity·부분bake0..1은 원본 Sequence 검증true인데 출력false였어요. 새 외부 상수 키가 불필요한 arriveTangent≈999999를 받아 Sequence 한도100000을 넘었고, Timeline 한도1000000만 확인했던 unit이 놓쳤어요. 상수/default 외부 기울기를0으로 생성하고 같은 steep 후보를 두 validator에서 검증하는 것이 수정/반증 경로예요. 기존 선형 외부 기울기는 유지하며 내부 큰 기울기는 finite control로 남겨요. 처음 설치 후보의 일반 UI/D3D 통과만으로 이 경계까지 완료로 세지 않아요.

2026-10-23. 새 domain 수치 검사의 모든 외부값/내부곡선/예산 검증 뒤에 fixture 계약 오류가 있었어요. `validTimeline`은 name·기본 interpolation이 필수인데 누락했으므로 fixture를 보완했어요. 다음 실패는 벡터 키를 `animationCurveSampler`에 넘긴 검사예요. 해당 샘플러는 소스상 Float64Array(1)의 scalar 속성 전용이고, Array.from 변환만으로는 벡터 지원이 생기지 않아요. 엔진 sampler를 확대하지 않고 같은 저장 키의 X채널을 scalar 키로 투영해 동일 oracle과 대조하는 것이 다음 반증 검사예요. 이 fixture 실패를 엔진 구현 성과로 세거나 전체 벡터를 scalar sampler에 다시 넘기지 않아요.

2026-10-21. 최신 구현/설치는 CODEX_HANDOFF.md·docs/research/ENGINE_STATUS.json을 먼저 읽어요. 전체 누적 목표는 active이고 완료가 아니에요. 이전 긴 진단은 Git의3d83a96:DEBUG_HANDOFF.md에 보존돼요. 잘못된 옛 설치485 정보를 현재 버전으로 쓰지 않아요.

## GL 초기 준비

Complex141 주 경로의 약7–8초 지연은 남아요. 1287–1289에서 꺼진 곡면 가이드 분기의 정적 제외는 실제 제품에 채택했어요. 보조 가이드 관측6276.9→1859.1ms·제품1827.4ms이며 전체 raw-half 성분307200개가 비특화 기준과 같고 on/morph/off·타깃/노멀 재사용·disable 해제를 확인했어요. 주 경로 제품7169.2ms는 개선 성과로 세지 않아요. docs/research/GUIDE_PROFILE_1290.md. 일괄 제출·비렌즈/무광·공유 노멀·메타데이터/차분 절삭과 과거 실험을 대조하고 반복하지 않아요.

1086-ueGYSG: 현재 robust normal decoder로 맞춘 정확한 보유 GLSL에 레지스터 SSA/0초기화 제거 후보를 raw GL ABBA 대조. path7197.35→7125.40ms/guide5295.55→5233.40ms,74B만 감소. 캐시/부하 미통제의 약1%로 개선 입증 안 됨. 기본 렌더러 미채택. 보조 픽셀의 관측성 검증이 없어 promoted=false/pixelObservabilityVerified=false. 후보의 같은 값/실험 파일을 구현 성과로 세지 않아요. 다음에는 작은 SSA/초기화 실험을 반복하지 말고 실제 컴파일 비용 구조·새 가설을 세워요.

1300–1308: 불투과 분기2050B제외/고정4tap/적응2·4tap/HDRI명시LOD0/빈매질카메라배열제외는 전체307200raw-half차이0이나 기준7066.5 대비6757.8/7030.7/6786.8/6942.5/6832.1ms로 확실한 개선을 입증하지 못했어요. 제품 미채택·후보는tools의사설모음만. 1306 fresh primary HLSL 첫구역73893B/PathSample9144·TraceCone2882·실제Program2741B; 정상원시출력/GL오류0. 다음작업에서이5후보/1086반복금지. 자세한원인후보·실패·다음비용경계는 docs/research/PRIMARY_PREPARATION_1308.md.

## 거리장 LOD

1087–1093은 화면 footprint 기반 per-geometry 정밀도·낮춤250ms/기존 필드/예산/취소·WeakMap 정지 투영/TAA·0인스턴스 해제를 실제 제작/실행에 연결해요. 전역 clipmap·bent normal·방향성 하늘·시간 신뢰도는 별도 잔여예요.

1090 첫 VxQUI4의 reduced16 timeout: 실제 sphere/카메라를 근거 없이16으로 가정한 기대가 틀렸고 실제12·pending0·실패0이었어요. 엔진을 바꾸지 않았어요. 독립 투영 정답은1087, compiled C++ 전달값64/상한과최저 사이의 축소/복원·모드/실제 native 픽셀은1090으로 구분해요. postProcessSettings가 post-volume.js의 직접 export라는 초기 CPU 검사 import도 도구 오류였어요.

기존912 고정예산 업그레이드/이전 필드/예약/취소 회귀가55,15를 유지해요. 현재 확정 검사·설치 SHA는 ENGINE_WORK_1094.json 및 후속 영수증을 따르고 실패 자료는 통과로 세지 않아요.

## 실행/공간 규칙

백그라운드·소유 임시 프로젝트/프로필/포트만. 사용자 창/서버/프로필 검사·종료 금지. 무거운 검사/설치 전 activeInstalledVersions를 확인하고 사용 중이면 미뤄요. 같은 소스의 native Player/Host와 증거 재사용. Versions1·최종 묶음 검사·공유 캐시/임시 런타임 정리. 한글 동일 author/committer 커밋·푸시를 유지해요.

## 거리장 쿠킹1098–1102

정적 도형/OBJ/glTF/GLB 자동 패키지·기하/생성 소유 지문·결정 바이너리·손상 복구·shared CookCache128MiB/패키지32MiB·기존 소유 교체/예산/취소·세렌더러 연결. 1098 최신9BBG3v는9그룹,1100-6Ymv0a GL/GPU hit2→3/복원/직접광·GL프로그램/TAA,1090-vN91ge 실제 CPP/BP/D3D 최초hit2/workerStarts0·복원,1088-2gmKD3 소유/취소 회귀 통과. 초기 검사 binary를 텍스트 API로 쓰기·기본 프로젝트 포함 모델을 누락한 필드 개수·직사각형도 다시 읽는 bytesRead 가정은 검사 오류였고 엔진을 기대값에 맞추지 않았어요. GL초기지연/전역clipmap/다중LOD·FBX·월드·편집기 쿠킹/누적목표는 남아요. 고정 출력 ai-context-1058.json은 이번 검사기로 갱신됐으며 새 근거는 distance-cook-ai-context-1102.json에 별도 보존해요. 이전1058 파일을 과거 SHA의 새 검증으로 세지 않아요.

## 반사 혼합·포즈·노멀1106–1112

브라우저 dual affine fade/base remainder·맵별CubeUV·GL172032B앵커/약한uniform bank·GPU stable sampler ID/분기전 normal/view·base intensity/rotation·필터/clone/refraction 수명·CPU skin/morph 현재경계/캡처전갱신을 연결했어요.1106-rsIzi5/1108-mxacl3/1107-PIVBqz 통과. UV없는 glTF 검정반사는 기존 hbNormal의 normalize(0): X7CU9x의실제map/uniform/binding/texel은정상이었어요. 공용GL/GPU 기본·코팅frame보호후1109-rog0AT 24조건씩·실제CPP/BP NativeFtfibr/GLQn5es9/GPU IWdwOu 통과. 오차완화/UV추가없음. 임시드로훅제거. 같은GPU geometry schema교체검사는Three캐시와충돌해독립geometry로검사하며schema교체완료미주장. 최종설치1114에서세백엔드실제CPP/BP모프와GL/GPU혼합·각24노멀조건통과. 확정USER_INSTALL_1114.json우선. 전역후보/우선점유·임의shader변형/instance morph textures·GL초기지연은잔여예요.

## 전역 반사 atlas1116–1131

PROBE_ATLAS_1130.md에 실패/수정/통과를 구분했어요. 1117 상수DataTexture만으로 놓친 WebGPU WebGL폴백 RT blit destination endpoint 오류를 소유FBO 어댑터로 고쳤어요. 실제gradient PMREM 각54조건/세모드 통과. Native 수동 corner per-lobe 전개가 FXC9.69초 관측: GPUborder padding4.45초/once-selection4.24초/최종4.37초. 통제ABBA/전체로딩/FPS미주장,GLComplex1418/7초와별개. 1120의잘못된BP핀/바닥피벗/legacyambient/invalidSkyLight16/HDRACES색역fixture수정과실제통과구분. 최종GLtShlaw/GPUJuyK49/D3DPpduDz 및 SDKRMzcPS(오차1/허용2·paddingStaticReuse). nativeorthographic off-axis view와ambientmetal/물리단위는별도잔여,현재중앙ambient0검사로증명하지않아요. 최종1133 설치에서GL/GPU/폴백각54gradient·직접쌍회귀·실제CPP/BP세실행기4영역/밝기복원통과. USER_INSTALL_1133.json확정. 이전one-shot재실행금지.

## 카메라·주변광1135 이후 작업 중

후속 변경은 확정1133 설치와 구분해요.1136의 큰 노멀 직값은 기존±10000 작성 제한으로 거부돼, 유효한 리터럴의 곱셈 그래프로 큰 유한 중간값을 생성했어요. 좌표 기본값 변경은 원인이 아니었어요. 검사 draw 인자/경고/잘못된 cbuffer 쓰기를 바로잡았어요. 공용normal GLSL→HLSL 변환의 st.s/t를 x/y로, 화면Y를 -ddy로 변환했어요. 실패를 통과 근거로 세지 않아요. native viewDirection float4/ambient Lambert·금속, GL/GPU graph ViewDirection/Fresnel은 검증 중이에요. 기존GL8/7초와 구분해요.

1138 실제카메라검사의R회전은기존Scene/BP API의도단위를라디안으로잘못작성했어요. world-visual-update/scene-environment의degToRad와대조해입력만180/π로수정했고렌더기대각도/허용2byte는유지해요. native/브라우저독립수식54/38조건과구분해요.

1138 ZB5FJR는회전후첫두픽셀이독립기대217/206/231과같았고세번째는배경39/47/52였어요. 가까운평면/넓은직교카메라를회전하면영상면의가장자리광선시작점이평면뒤로넘어가가림조건이달라져요. 실제평면을관측하는화면40/50/60%세지점으로fixture만수정하고기대방향/색곡선/2byte기준은유지해요. 실패정지시inspect도저장해다음추측반복을줄여요.

1143 최종설치 검증확정: native54조건·GL/GPU/폴백각38조건·atlas각54gradient·실제CPP/BP세실행기카메라4상태×3픽셀·전체소유SHA/명세/User보존/Versions1통과. USER_INSTALL_1143.json이최신. 작업중/미커밋으로기록한위단락은이후확정근거로해소됐어요. GPU내장Physical/probe전체시선·native기본맵경로는별도잔여예요.

## GPU physical view1145 이후 작업 중

현재설치1143과미커밋변경구분. builder-local PV변수에projection uniform으로직교상수를variant/lighting전에대입. rawlibrary/factory/clone를WeakSet으로장식하고dependency/globalTSL불변.1145-zCp4L5 실제GPU/강제GL폴백 각vector24/physical12·기존오차유지·정지평면불변0·이전오차.3재현. 초기vector검사광원의spec오프셋/시선공간기대오류는fixture수정.

Iridescence: Three TSL mat3는JS Matrix3 행우선,GLSL mat3는열우선인데동일배열이사용됨. 명시XYZ dot행의thinfilm으로교정. GL multis호출은이름F0인인자에film Fresnel을전달하며평균반사에도Fr사용,TSL은역Schlick F0/기본색평균이었다. Favg단독후보는불충분. model.start가super.start에서빛을소비하므로start후교체는효과없었고첫consumer전에owned필드를준비. 이변경후직접광이GL과일치했고간접광입력까지맞춰1145통과. 실패를성과로계산금지.

rawvolume 시선도owned call의slot1을교체. call은VarNode로감싸질수있어최대4단계unwrap/15입력검사. 직접source바꾸지않고원래texture owner보존.1146은CPU독립spectral sum/기존rawDFG·authoredSchlick 투과정책을각각대조. 처음0광원은lighting model이생략되어0세기Ambient를명시,잘못된순수Schlick raw기대는실제DFG와대조해수정. 오차기준유지.

fallback readback뒤copyTexSubImage2D가GL1282. Float32blend가설은HalfFloat에서도실패해기각. gl개별call계측과실제copyTextureToBuffer본문으로READ FBO를직접bind/삭제후미복원, PBO미해제를확인. 현재새adapter는tracked READ복원/packalignment·PBO상태복원·fence전복원·PBOfinally삭제.1146재검증중. 임시계측은검사코드만,운영픽셀읽기추가없음. GPUPhysical/volume/보관source검사와최종설치완료전전체완료주장금지.

1147 첫 실제게임fixture는 기울어진 view에서 Roughness .35→.85의 차이가2byte라 가시변화>=4byte 조건에 실패했어요. C++ 호출 뒤 실제 픽셀변화와 상태보존은 관측됐으며 생산오류로 판정하지 않아요. 임계값은 유지하고 specular를 관측할 수 있는 초기 카메라에서 재질편집/복원을 먼저 검사하도록 순서만 바꿔요. off-axis 불변성은 모든 상태에서 유지해요.

1151 설치 검증 확정. 원래 install1151 job handle이없고해당실행프로세스도없어중단확인;이미통과한3gate를재사용하고새resume으로미완료게임만이어갔어요. 첫복구시빌드import구문오류는installed220파일의동크기all-zero손상;repo/dist정상/명세불일치,hardlink아님.원인미확정. repair1153이명세SHA바이트만원자복구·3857전체/독립Nodeimport불변·이후CPP/BP실제3렌더러/최종전체SHA/User보존통과. READ/PBO손상과파일손상의원인을혼동하지않아요. install/repair/resume/finish one-shot 재실행금지. USER_INSTALL_1151 최신.

1151 후속6gate는각각acceptance/정상exit로보존됐어요. 마지막프로젝트연결이이전4940경로라원래통과6검사재실행없이새resume1156에서격리프로필--register만실행·전체명세/소유SHA/User읽기SHA/링크/연결재확인통과. 새설치/버전추가없이복구,Versions1유지. 파일손상원인과등록되돌림원인은확정하지않았어요.

1157–1162: 공간/CPU 후보/정수표현/재사용을 먼저 묶은 뒤 batch1160으로 검사. CPU1157-Ip0jVb, selector1158-QAWPmx, atlas1117-EUpJpG, native1119-e7hLIO 통과. 첫 실패는 검사 GCC PATH, 정상 EOF판정, GPU기본Camera fixture이며 알고리즘 임계값완화없음. native unsigned count0 방어 뒤 해당gate만 재검사, 이전성공은소유SHA재사용. Player1161 한번빌드. 다음은API/AI/소유원장·신규설치 및 CPP/BP3실행기 확인. 이전1151파일손상원인은미확정으로유지.

1165 사용자설치 확정: 실제CPP/BP세렌더러4공간이동/밝기/복원과노드7/공간재구성불변·전체파일/소유SHA/User/연결/Versions1 통과. 선행묶음4gate는소유SHA로재사용,재실행없음. USER_INSTALL_1165 최신. 아직전체HDR/FPS/타엔진누적기능완료는아니에요.

1177 설치확정: 기본normal/D3Dsource·설치GL/GPU실제glTF C++/BP광원5상태·공유65536영역(1캡처)/144B부분전송·수명·소유진단. 5gate성공SHA재사용·Player1173한번빌드/Host재사용·3878명세/542소유SHA/CPP19/User/연결/Versions1. 처음fixture가surface전용API라normal을제거한것과Windows near/far매크로충돌은검사도구수정,허용오차완화없음. 전체캡처/FPS·명시tangent/임의그래프동등성은구분해요.

1183 설치확정: 프로브table변경행·대기변경/full우선·GLunpack복원·세렌더러픽셀/인스턴스/해제. 두밝기288B 대조1008B·정지0. C++소유14/CPP19/Player1173/Host1041재사용으로컴파일·게임반복검사없음. 3882명세/544SHA/User읽기SHA/연결/Versions1. 실제FPS와구분.

1190설치확정: native CPU설정전용/4B공유index·65536영역768KiB절감·불량혼합원자거절/9구간정책. 영향native2gate+동일HLSL/raster증명으로노멀/브라우저반복검사생략. 설치CPP/BP4영역/밝기/복원 layout1불변/fast0→1→2·캡처/copy/공간재구성없음. Player1186한번빌드/Host재사용·3884명세/544SHA/CPP19/User/연결/Versions1. AI인계길이실패는축약후정적검사만재실행.

1201설치의Sphere패키징실패는scene에양수scale만허용한기존계약이원인. fixture음수비균일scale유지하고저장/편집/노드/CPP/생성/풀/저장/물리/복제/시퀀스및native면판정함께수정.1208설치3backend9상태통과·capture/copy불변. native48조건/Rapier2D·3D/구1040실행·동일브라우저수식재사용,Player1204한번.새기능이구1190설치에검증된것처럼표현하지말것.

1210–1217: Gate 실제 다중exec입력 제작에서usedInputs/connect가단일선만허용하는결함확인→data만단일·exec입력합류·모든선행Setter삽입수정. Promote가변수만추가하던것을Get/Set/체인연결수정. UI최초종료실패는dirty-own문서종료대화상자,문서save후정상. 최종sourceCPU1699/GUI/NativeCpp/기존VM과설치Windows5/8/8분기통과. binaries변경없어Player재빌드/GPU매트릭스없음. 복제installer의scope과거Sphere문구는원문보존후실제필드로정정.

1219–1226: 기본월드C++형식이항상Actor여서2D/기존Character typed pin이null→Builtin class factory/한번생성/원래pose유지. User factory가GameInstance같은builtin에도unknown class→한스키마actor목록으로배제. Pawn2D CPU초기fixture는TopDown컴포넌트로Character2D를추론해잘못선언,명시클래스메타데이터로fixture수정. 실제preview toolbar canvas아래가림→flex별도행,직교회전잠금/동일방향수정시camera보존. 최종CPU50/실제GUI2x2Sprite·OBJ3정점/idle0·Spawn회귀·설치D3D11CPP2D게임통과. Player1223한번빌드,Host재사용. Versions1/User읽기SHA.

1228–1239: collapsed 소유flag로기존macro VM재사용, 순수macro가__deferred로빠지는조건수정·openpinliteral/default/단위scale보존·typedreroute Expand/새ID복제/주석watch. 선행exec합류collapse에서두번째선중복제거로누락→도착entry공유+양끝중복만제거, CPU/GUI E입력실행확인. 펼친helpers기존노드와겹침→기존placeHelperNode+선택focus. 상속authored proxy가필터배열반환→viewHint·부모scope보존/childserialize/readonlyguard, 실제설치child+parent동작확인. 모델42/배열6종·UI·기존flow1699/CPP·상속JS17·설치D3D11package+상속editor통과. Player1223/Host재사용, renderer matrix없음. 당시core VM후반변경없는성공재사용scope는batch1231에명시.

## 1266 GL 준비 지연: 읽기 전용 생성 구조 대조
보존된 complex141-980-sLKAfd의 path/lens GLSL에서 material 함수4441145는각1313B·texture호출1·정의포함참조3. path전체120707B/lens117593B이며 원본M_Complex141그래프는6노드예요. 함수복제/레지스터정리가 주원인이라는 근거는 없어요. 1086 SSA/zero-init실패재측정·GPU컴파일·셰이더제품편집은 하지 않았어요. 이 수치는 보존된 역사적소스의 구조진단이고 현재시간/FPS개선근거가 아니에요. RND-06의8/7초잔여를완료처리하지않아요. 다음실험은 실제분기/인라인fanout·드라이버단계비용을분리할설계가필요하며동일74B실험반복금지예요.

1320 검사준비 정정: vUvy0O는 임시프로젝트 BP parent와 기본 DoorController 원본 불일치,7YEBTS는 도구 인라인 quoting 실패로 새 Source 파일 누락. 명시적 ListController 원본/경로를 생성하여14JfLO에서 실제CPP실행 통과. pksver는 기능검사 뒤 수정한 클립 미저장으로 정상 종료 확인이 막힘; 저장 후 같은 영향gate만 재실행하여14JfLO 종료0.1323밀도 첫 fixture는 기존1024키 Sequence 예산을 잘못 가정했으며, 실제65536키를 지원하는 skeletalclip 소유자로 바로잡아ZdKkWn에서 데이터/선택/표시밀도/수명 확인. 실패를 성능·구현 성과로 계산하지 않음.
1337 재현 정정: Euler UI 검사가 두 번 같은 원본 회전을 보였지만 수학 모델7그룹은 통과했다. 별도 실제 창 KXclZh에서 회전 timeline 버튼이 display:none·rect 0임을 확인했다. 검사 click은 트랙을 바꾸지 않았고 위치 커브의 select에는 Euler option이 없었다. 커브 닫기→표시된 회전 선택→다시 열기에는 올바른 option이 있다. 반복된 선택 핸들러 가설 수정은 원인 해결로 계산하지 않는다. 다음은 보이는 곡선 트랙 선택기를 추가하고 동일 도구를 그 경로로 검증한다. Euler 수식/원장 gate/키 데이터를 임의로 바꾸지 않는다.
1337 Hg2Ln3: 보이는 곡선 트랙 선택기로 위치/회전을 전환하여 부분 베이크19키·Undo·AI 경계 거부·Euler UI/AI·실제 BP Play/Pause/Seek 위치[.5,1,0]/회전[0,91.5,0]까지 통과했다. 검사 생성 문자열의 따옴표 오류는 node --check에서 바로잡았으며 실행 성과로 계산하지 않는다.

1345–1346: standalone 키 복사/잘라내기/붙여넣기/Undo 통과 후 nested Sequence paste가2키만유지. 읽기진단WV3XcS는 첫 Timeline DOM이실제로보이는vec3임을증명하여숨은창가설배제. cF0xca가바깥스크럽2.00/내부curve.time0을증명: Gameplay.scrub/timelineTime가inner곡선시간을갱신하지않음. timelineTime→inner시간/표시(false sample) 및 inner sample→outer표시 동기화·바깥수동스크럽의inner재생정지로수정. 이후fixture의노드중첩/없던inspector버튼과생성문자열quoting실패는검사준비오류로분리하며성과계산안함. OS클립보드는검사전체에서private stub만사용.

1348 실제BP Timeline 결함: renderBlueprintGraph의삭제검사가구id timeline:<node>를새id timeline:<document>:<node>와비교해모든창을제거했다. openTimeline의getNode가doc.data사본을수정하고changed()가graphs.blueprint를직렬화해키변경도버렸다. DoJKxT/floating-state는키복사5회후Timeline창없음·본문2키를보존. 새문서/노드소유검사·dispose와active graphs실제노드편집/비활성쓰기거부로수정. 직접소유하지않은상속Timeline은원본편집안내. 기존단일Curve모델은반복검사대상이아니며해당실제GUI경로만다시검사.

1357–1359: 첫 GPU 실패는 구의부피113이기존상자96보다커져후보순위가바뀐fixture가원인,명시importance1로정정. 다음 실제WebGPU만 box복원시x4픽셀[0,0,2] vs[.25,0,1.75]가재현. WVSL36QujD는mod4/조건분기정상, CPU nodeUniform20[1,0,1,1]·lo[-3,-2,-2]/hi[3,2,2]도정상. Three0.180.0 sourceUniformsGroup319/build57317의updateVector4가offset+4와v.w비교해w-only7→1에서다음uniform.x1과같아전송을누락. 소비하는source/canonicalbundle를checked patch로offset+3수정. 3XP8cV의GL/GPU/forcedGL각2560pixel·legacy복원통과, wHcuUr의실제NodeUniform1→7→1/인접보존/정지skip·fakeguard통과. 추측mod수식/캐시불변식을임의변경하거나engine-wide FPS개선이라고표현안함. 별도검사준비: 미export nodePins→effectivePins,baseUniform→NodeUniform,native Win small/far 매크로와const Program인자수정은성과제외. Native9vIF5n 실제8192/최대1B·굴절8/오차0, Player1360한번24.67초·QCu2wJ C++/BP5상태/캡처4·copy150·layout1유지.

1366–1373: DirectX probe/2D CB는 같은 값도 draw마다 Map하던 비용을 슬롯별 성공 바이트 cache로 제거. 실제3000 draw: 각각3upload/2997skip, CPU1584B·GPU자원추가0, SRV만 red→green/강도/제거복원·기존2D mask/light/cookie/stencil픽셀 통과(lC4Plh). Player1369 한번24.65초; packaged1371 C++/BP/자원보존과 증가 skip실측. BP Timeline삭제 hook을 changed이전 현재graph에 적용·한Undo track/wire복원; rename후 close disposeMap은 editor동일성·disposeOnClose, 실제GUI A1goeS통과. context focusRoutes심볼hit는3파일169453B/151.29ms; --all891파일7309870B/348.17ms, miss자동fallback/범위명시. 초기 pure링크절대Korean경로/다중auto다른타입·GUI없는title에replace·검사이름일괄치환의노드오타는 fixture준비실패이고 제품성과제외. native bridge mainCB/전체FPS/주GL약7초 해결주장금지.

1378–1381: 곡선 임의 경계는 (time,value) de Casteljau·기존0..1 weight표현보존, 모양범위밖/수직핸들·키도메인밖은편집전체거절. source80case/292400scalar관찰/최대8.88e-15, 기존1336/1319회귀통과. Butterworth spectral FFT는등간격>=4/저고역/Hz/1..16차/강도·반사2duration/선형radix2재표본·키시간수유지/채널및선택밖값보존/원보간유지. analytic774/최대7.11e-15·65k약122ms편집CPU/재생FPS아님. 새runtime상주0/native불변. 사람우클릭/도구옵션·FFT/임의범위·Undo/AI revision/dryRun/stale·Sequence/skeletal/BPTimeline/실제Play2.5 source GUI통과. Chebyshev/비등간격직접필터/고급rig/Euler/다중curve잔여유지. 설치1376초기script괄호는nodeparse단계실패·실행전수정/성과제외.

1386–1389: Sequence트랙65536/기본총262144(종전256x1024최대보존)/총keyBudget<=1M, 개요8px첫끝/선택원인덱스·속성32키/번호점프·전체시간임시배열제거·공용clip예산. source10k샘플오차0·실창IiCQT1 204마커/32키입력/1063DOM·열기773ms·65535수정Undo/AI페이지/복사/저장·복구flush/Play통과. 첫O5el93는기존poll4MiB보다큰응답으로전송재시도→120s만료; 새16/14MiB배치·1회인코딩·RESULT_TOO_LARGE·8ms양보·동일timer/500ms실패재시도/stop늦은결과폐기. bo0UUf는복구localQuota/저장body8MiB(기준+새text)문제, 주복구32MiB·보조256KiB best-effort/oldstale삭제·에셋write32MiB·동일의미저장noBackup·원본충돌보호. GYz4Ii copied.result.clipboard wrapper 검사오타·script중복const 등준비실패는성과제외. Legacy session백업Quota는onBackupError기대로수정/주디스크에러보존검증. Node스토어LPIfnB9MiB/reload/변경1백업/noChange0·model1388UTF8/5MiB/분할/50/FIFO/늦은stop통과. Native불변·주GL지연/스냅샷Undo/일반대형문서부분조회잔여유지. 앞선진행설명1MiB는일반기본body값혼동, 실제자동화route구한도4MiB로정정.
1390–1391: SequenceEventIndex는event트랙4B/key만추가·이진구간/private후보4B/match·원배열순서/중복/initial/endExclusive/seek유지. 140predicatecases/재진입/키배열교체·실제headlessGameplay dispatch,65k/빈구간10000/시간접근320002/6.44ms·기존timeline/계층5/구간15회귀통과. OnSequenceCompleted를최종키로잘못기대한fixture는완료callback포함으로정정/성과제외. 범용document.read는ownJSONPointer/~1→/~0→~/기본형태/id/name·값복사/offset/limit1000/nextOffset·revision불변, 실제SaHnic큰문서/부분조회/저장/복구flush/Play통과. primaryStorage한도32M·NoChange백업0확인, shadow snapshotUndo와큰단일문자열분할은잔여. 실패dense프로젝트3개는완전SHA대조ZIP으로압축보존해14759587B회수(native/build/dense-fixture-compaction-1390.json); 사용자/성공소스/보고서보존.
1391 최종GUI Vl1Mi6: 키번호네비게이션을속성상단고정·선택행자동스크롤/강조, 마지막키value실제가시성검증,32키/204마커/1095DOM/열기797.69ms·부분문서/시퀀스조회·원본/복구저장/Play통과. CPU샘플값과창가시성은구분.

## 1396–1402 — 문서 이력 구조 공유와 시퀀스 다중 트랙

- 기존40개 문서 Undo가 작은 키 변경에도 매번 전체 JSON을 유지했어요. 일반 트리의 바뀌지 않은 부분만 과거 기록과 공유하고, 복원은 복사해 편집·기록을 분리했어요. 비JSON 그래프는 structuredClone으로 폴백하며 이름 변경의 과거/미래 참조 갱신을 유지해요. 파일 묶음 표시/충돌 형식은 바꾸지 않았어요.16x16384키 실측 유지힙49,018,776→7,344,992B, 생성289.06→162.09ms; 실제 애플리케이션 전체 메모리/FPS 수치가 아니에요.
- 시퀀스 개요는 행을 전부 만들고 모든 행의 키 밀도를 계산하던 경로를 보이는46px 행+overscan3으로 바꿨어요. 전체스크롤/원인덱스·포커스/드래그·선택·키페이지는 유지해요. 검색·중앙 재지정 단축키·AI 메타페이지/정확키 이동/예산 있는 이력 진단을 함께 연결했어요.
- 첫 window KFT0Tj는 검사 도구가 editor.undo에 필수expectedRevision을 빠뜨려 실패했어요. 제품 revision 가드를 완화하지 않고 도구를 고쳤어요. AJbceQ는 모든 UI/Undo/Redo/분기/저장이 통과한 다음 재생에서 가상 타깃 Ghost1이 없어 기존 엄격 검증이 거절했어요. 제품의 누락 타깃 검증을 제거하지 않고 검사 씬에255개의 실제빈타깃을 추가했어요. 둘은 완료 증거로 계산하지 않아요. 소유 실패 프로젝트2개는 모든ZIP entry 크기/SHA를 읽어 대조한 뒤 원본디렉터리만 제거해35,548,457B를 회수했어요. 재현ZIP/manifest/실패보고서는 남았어요.
- 최종 source Soyawj:256트랙/첫행10·348마커/맨아래6·96마커/전체높이11814/검색1행,65k마지막키 가시이동/8 UndoRedo/분기·읽기revision·저장·실제Play2.5. curve-filters Z13QF1은 실제Sequence/골격/BP Timeline·FFT/경계Bake/Undo/저장/Play 회귀를 통과했어요. source 이후 추가된 선택행 색/기본키 재지정과 입력 격리는 설치gate에서 확인해요.
- 잘못 추정한 도구명check-asset-shortcuts.mjs는 실행 파일이 없어 준비 단계에서 실패했어요. 실제 check-editor-shortcuts.mjs의153명령 회귀를 통과했어요. 성과나 제품 실패로 혼동하지 않아요.
- snapshot 전체 순회/복원·scene/BP 사전직렬화·변경대형배열, 큰클립/섹션/비고정행과 고급다중곡선은 남아 있어요. 임시후보를 채택했다는 주장이나 전체엔진완료 승격은 없어요.

## 1407–1419 독립 반사 투영과 네이티브 상수 공유

- 독립 프록시 외부 광선은 기존 내부 출구 수식과 달리 가장 가까운 앞 교차점이 필요했어요. CPU/GL/GPU/FXC를 같이 수정했고 독립 THREE Ray/Box/Sphere 2,211개 조건과 대조했어요. 회전·전단된 수치 경계는 부동소수점 분류가 불연속이므로 정확한 경계 표본은 identity/이진 구 조건으로 분리했어요.
- HLSL `point`는 예약어여서 컴파일이 실패했어요. 네이티브는 `worldPoint`로 수정했어요. 테스트의 잘못된 offset 기대값·혼합 auto 선언·braces·허용되지 않는 vec2/vec4 직접 surface 연결은 재현 코드 오류로 고쳤고 구현 성과로 세지 않아요. 그래프 자료형 검증을 완화하지 않았어요.
- 공유 프록시 모양을 바꾸면 참조 중인 프로브 일부가 달라질 수 있어요. 렌더 수집은 무한 투영으로 안전하게 돌아가고 서비스의 새 불일치 할당은 거절해요.
- player-iFEXpj 준비 timeout을 보고 scalar box loop를 의심했지만 vectorized slab/[branch]만 적용한 3eUccE도 81,683.60ms였어요. 이것을 근본 원인 해결로 주장하지 않아요. 원래 failure.json과 프로젝트는 SHA 확인한 repro.zip에 보존했어요.
- 머테리얼 5개의 HLSL을 비교해 발광색 literal만 달라도 전체 pixel/shadow 소스가 달라지는 것을 확인했어요. Native-only 직접 표면 상수의 uniform 승격과 레거시 같은 속성 wrapper 제거로 5→1 소스를 공유해요. 산술/명시parameter/정적 분기/원본/읽기전용 표면 setter 의미는 유지해요. 발광 문서당 값 +12B와 별도 CPU/GPU 비용을 기록해요.
- 새 고유 프로젝트/profile의 N0h1ta 29,401.78ms, ezzcMY 30,341.71ms 준비, shader queue9실제/8중복제거, 디스크0hit/10miss 관찰. ezzcMY 내부 shader preparation809.40ms와 전체 준비 시간을 구분해요. 통제된 CPU 부하 반복 실험·FPS·복잡한 GL 초기지연 해결 증거가 아니에요. 원래82초의 모든 시간 원인을 특정했다고 표현하지 않아요.
- ezzcMY 실제 DirectX 게임: 4방 중앙 픽셀 (194,0,0)/(0,194,0)/(0,0,194)/(194,194,0), C++/BP 6번전환 metadata만224B씩 증가·이미지4/copy150/layout1 유지·위치(6,0,2)·즉시C++값 캐시. 수치/브라우저 physical/raster/UI/기존2D·혼합은 projection-final-1419와 개별 receipt로 구분해요.
- 초기1418 검사는 private 실패 프로젝트에 의존했어요. 공용1120 fixture를 메모리에서 생성해 portable로 바꾸고 다시 통과했어요. AI context 검사는 임시 인계가5KB를 넘어서 실패했고 인계를3,949B로 줄여 기존 한계 그대로 통과했어요.

## 1424–1432 반사 영향·시간 진단·AI 조회

- CPU 독립 변환 평면/각도/노멀 껍질 5,400조건 오차1.11e-15. GL/TSL/native는 같은 구현을 oracle로 쓰지 않고 이 표본과 대조했어요. exact 회전 경계의 불연속은 identity 경계와 분리해요. GPU 수치와 실제 physical+clearcoat는 별도예요.
- 첫 GPU 검사 함수 문자열의 newline escaping, private server가 제공하지 않는 tools import, fake PMREM 함수의 다섯 번째 position 인수 누락은 검사 코드 문제였어요. 문자열 raw·oracle inline·올바른 인수로 고쳤어요. 공용 native 검사 driver의 출력4096 한도를 늘리거나 표본을 버리지 않고2chunk로 전체5400을 실행했어요. 엔진 객체 한도와는 관계없어요.
- TSL If 첫 분기의 implicit assignment 반환/다른 분기의 void가 `expected float` 진단을 냈어요. 둘 다 명시적인 void 블록으로 고쳤어요. 경고를 무시하거나 tolerance를 넓혀 통과시키지 않았어요.
- 실제 GPU physical에서 후보1을 지웠는데 파랑 후보만 남았어요. 디버그 WGSL은 아틀라스 table load 없이 기존 direct uniform source였고, 데이터 table과 advanced flag는 맞았어요. 일반 Three 머테리얼은 render-object key 조회 뒤 node material로 변환돼 envNode 변경만으로 이전 builder를 재사용했어요. GPU 바인딩 node ID를 원래 customProgramCacheKey 함수에 덧붙여 mode/owner를 구분하고 값 변경·복원은 유지했어요. 현재 실제3백엔드의 후보2/3승격·부분페이드·outward/inward·default복원으로 확인해요.
- 첫 physical oracle 비교의2.54e-3 차이는 검사 renderer에 실제 엔진의 installGPUCameraView가 빠졌기 때문이었어요. 같은 adapter를 설치한 뒤 허용오차1e-4로 강화했고 ikwWo9는 GL4.47e-9/WebGPU2.24e-8/fallback4.47e-9예요. 느슨한 이전 oIyrxR를 최종 근거로 승격하지 않아요.
- 기본 optional metadata 생략은 이전 record만 가정하면 count 증가 시 옛 BVH 영역을 새 레코드로 재사용할 때 틀릴 수 있어요. count 변경은 강제 초기화해요. 실제 CPU atlas/512행 typed-array Proxy2048읽기/0쓰기·byte복원/동일크기count성장/실제resize/reorder 검사를 통과했어요. fake GPU copy라 GPU시간/FPS로 확대하지 않아요. stub backend 누락은 검사 코드만 수정했어요.
- 준비 elapsedMS가 완료 poll마다 늘던 것을 고정하고 구간 합계/횟수·유휴 제외·취소·revision·실패를 연결했어요. 초기부터 ready만 관찰한 실제 게임은0구간으로 표시해요. 37.15초 전체 startup을 단독 shader시간0으로 해석하지 않아요. 이전29–32초보다 개선됐다고 주장하지 않으며 부하통제 실험도 아니에요.
- ipw9k1의 C++ dark pixel 뒤 metadata 통계는 capture 전 inspect 값이어서 한 frame 늦었어요. 최종 설치 검사에서는 capture 뒤 통계 증가를 기다리도록 강화해요. 실제 검정/노랑 및 C++ 즉시 cache는 원 실행도 확인했어요.
- 정확한 SetFaceFade 조회가 작업명과 맞는 수학 경로까지 합쳐5파일을 읽었어요. 등록된 exact symbol 경로를 먼저 읽도록 공용 context를 수정해3파일, 수학2파일/시간진단1파일로 제한해요. --all과 없을 때 전체 fallback은 유지해요. 모델 이해 속도나 전체 문서 분석 완료를 측정한 것은 아니에요.

1433 추가: 면별 setter의 벡터 배열을 호출자와 공유하지 않도록 복사해요. 실제 서비스 입력을 나중에 바꿔도 속성이 유지되고, 잘못된 두 번째 벡터는 첫 값도 반영하지 않는 것을 확인했어요. 생성 vec3핀/bool/float 검증·업데이트5회와 기존 우선 혼합401관찰을 통과했어요. 오래된1356의 ABI/계약 버전 단언은 현재320B/20행/v9로 갱신하고 수학 검사는 유지했어요.

1438–1443: Undo의 미변경 트리 결과 컨테이너를 지연 생성(ownedPrevious 내부 data-property 기록만); 기본 외부 getter 읽기·fallback/복원 격리는 보존. 몽타주 공용 행 탐색에서 row ID를 알림 ID로 고르지 않아 우측 속성이 비던 실제 실패 rkLB6c→defaultSelection 및 행 클릭 경로 수정. 3eFG6M은 테스트가 revision 없이 redo를 요청한 계약 오류→최신 revision 전달; production CAS 완화 없음. 최종4KZrbs 통과. 기존 montage-notify 단위 fixture는 runtime root-motion 인터페이스 extractRange가 없는 낡은 stub→루트 추출 없는 fixture용 noop 추가, runtime 수정 없음. 그룹1443 native17/test27/vendor2 SHA 동일로 재빌드/렌더러 재검사 생략. AI timelineRows2파일/143.87ms 관찰; 전체 엔진 해석/성능 보장 아님.

1450–1453: 시퀀스·몽타주 표시 범위는 view 전용으로 분리. 초/프레임 ruler, preview/runtime cursor, 키/클립/구간/드래그/trim/context의 같은 시간 투영과 clipped handle·범위 밖 표시 제외. 전체 키/구간은 유지. 실제960math와65536키 창 k54WSp의 Ctrl휠/Shift휠/RMB·MMB/AltShiftRMB/cancel/context/F재지정/키drag/section·montage trimUndo/save/Play 성공. 첫8MV2TS의F <.3초 기대는 fixture30fps(12프레임=.4초) 착오→fps계약으로 수정, production 줌 완화 없음. rows43상수도 실제 metadata42로 교체. 끝 키가 band overflow에 잘리는 새 회귀를 예방해 원래 예약 여백 접근과 selected z-index를 보존/실제 hit-test. 최종 교차문서 timeline drag→AI mutation/range/row/key navigation의 EDITOR_BUSY 장벽과 runtime커서 range투영 assertion은 설치gate에서 현재source로 확인.
소유 이전 fixture5개는 파일별 size/SHA를 ZIP에서 다시 읽어 일치시킨 뒤 프로젝트만 제거하여85073863B회수; 최종재현·보고서·스크린샷·사용자파일 보존. private PS5 도구의 UTF8 BOM/Get-FileHash/ZIP역슬래시/hashtable합계 차이를.NET stream hash/경로정규화/명시sum으로 고쳤고, 검증 전 삭제는 없었어요. group의 BOM receipt 파서는 UTF8 BOM을 제외하고 해시원본은 유지. native17/test27/vendor2와Player/Host동일, 재빌드·렌더러행렬 반복 없음.

## 1458–1464 enum 통합 진단
상대include 후보 중 bare ../ fallback이 정상 local후보까지 거절하던 파서수정. SDK -Werror의 misleading-indentation 정리·TryParse namespace거절/다른 auto자료형 선언분리. native fixture token누락/없는 SetPosition 사용은 fixture수정(실제 Actor transform API 사용), UI hidden 항목은 존재하던 저장값으로 fixture구성·saveCAS명시. AOT 두번째 소스는 파일목록과 code.source를 같게맞춰 중복번역단위 fixture수정. 기존 check-runtime legacy Switch는 modern makeNode의 빈 caseValues/flowOutputs를 섞던 baseline fixture라 legacy필드로 명시; 제품 legacy실행은 그대로. Source actual enum UI/인스턴스UndoRedo/save/Play, 2모듈portable AOT·SDK·core 회귀통과. SDK최종qualified-name guard수정으로1462뒤1464 Player재빌드. 전체렌더matrix반복없음. Enum::Name metadata는 generated worker등록뒤사용; 사용자 전역초기화순서·일반constexpr/조건부전처리/소스alias전체지원은잔여. GetFloat는float정밀도이며 enum 높은 비트는 typed native핀/함수/ToValue경로를사용.

## 1469–1483 값 구조체 통합 진단
C++ 공개 값 구조체/필드 타입·기본값·enum/Actor/배열 codec와 Make/Break/Set·참조 tunnel·속성/변수/인스턴스·시퀀스/Take 연결. UI 타입 변경에 이전 정수value를 넘겨 vector.map이 깨지던 문제는 새 타입 descriptor만으로 초기화해 수정. MakeStruct 타입 변경의 memberPins 잔류·C++ JSON 객체 키 순서 비교·runtime 배열128 재검증·깊은 sourceReference/default override 제한을 수정. 함수/접힌 그래프 포트에서 파생 선언 표 복제를 제거하고 VM metadata/default/field/reference plan을 읽기 전용 공유. 실제 portable2모듈 기본값42/55 교대 검사에서 generated HB_RecordOwner::HB_Checkpoint 외부 심볼이 첫 모듈 생성자를 공유하는 것을 nm/생성 코드로 확인; worker 내부 타입·함수/상태를 익명 namespace에 두고 외부 portable 진입점만 유지해 격리. 수정 후 native1479/portable1480 및 enum/legacy native/runtime/상속/시퀀스 회귀 통과. SDK include경로와 mask필드 삽입/오래된 sequence fixture API 착오는 검사 fixture수정이며 제품 기능 성과로 세지 않음. 실제값 구조체 클래스상속/identitygraph/fieldmigration·임의C++문법/전처리·전용structasset은 잔여. 새 GPU/worker/timer없음; 전체 heap/FPS 개선값 미측정·record checkpoint deep copy잔여.

## 1490–1495 checkpoint 비용·복구
첫 unchanged-record equality 후보는 직접루프6.3ms→11ms로 느려 미채택; 복사0을 전체성능향상으로 계산하지 않음. 최종은 optional record checkpoint·기존 표준/엔진 타입 propertyGet snapshot생략·propertySet수신cell만·함수/생성/사용자변환전체복구. 실제Cpp타입/클래스와nestedrecord를컴파일대조해 같은이름Vec3/Array/String이userconversion을실행하는경우전체복구; converter가다른Actor값/좌표를바꾸고throw하는Get/Set검사통과. 2Actor*128record*64nested/32Get Items대입64→0/32Set64→32·임의함수2Actor복구·앞선성공Set보존. fixture정적링크할당4/546→2/273B(wrapper+16B). 초기동적링크new계수는DLL내부stdstring누락으로heap총량을판단못하므로static비교로보정·관측자료기록. profilerfixture새counts프레임을패널앞에놓던순서/aliasJson괄호는검사수정. rawtransport5counter를ms와분리해프레임합·invalid수치제외/구worker호환/clone/상한확인. 생성worker가sourceKey에포함되어캐시재생성. 기존NativeBatch50actor/실패/operations/events/clock/reset·actionbatch·recordCpp·portable2모듈검사와최종typefallback검사를나눠필요한영향만재실행. 전체FPS/heap개선·임의Cpp상태의트랜잭션전체지원주장없음. SDK20owner/Player1484/Host1041/vendor2SHA변화없어재사용.

## C++ 접근 연결1501–1516

명시 반사 private/protected 멤버·중첩 클래스/enum·정확한 참조/배열 인자를 컴파일 사본의 friend로 연결했어요. 원본의 일반 C++ private 접근은 계속 컴파일 오류예요. 문자열 내부 세미콜론 때문에 regex가 속성을 자르는 실제 판독 문제도 lexer의 문장 경계로 고쳤어요. 두 AOT 모듈 state/enum/event 분리·CPP rollback·2D 포함 기존 50Actor batching·typed records·다중소스·클래스생성·AI 그룹12와 Android ARM64 NDK syntax4units 통과. source hidden editor/같은저장 D3D[14,3,2]/Score14/exit0 통과·최종 설치 gate는 USER_INSTALL 후속영수증을 따르세요. enum int32의 미등록 숫자13은 기존 합법값이어서 초기 검사 기대를 고쳤고 wire범위 초과4294967296은 거부해요. 큰 기본값의 AI조회는 페이지 필드만 읽어요. std detached1024-int 값인자 할당2→1/constref1/outref유지 직접계수·전체FPS주장없음. grouped 실패 원인·중간자료는 native/build 원래 폴더에 유지해요.

## 1872 분수 격자·키 선택 후 곡선 열기
실제 키 드래그·Undo 이후 curve FPS 입력이 없어 검사 실패했어요. 선택 키를 트랙으로 해석하는 클릭 처리만 고쳐도 renderSequenceCurve의 curveTrack===selection 조건이 남아 같은 오류가 재현됐어요. 다음 검증은 곡선 열기 시 소유 트랙으로 selection도 전환해 렌더 조건을 맞추고, 같은 키 드래그·Undo·곡선 열기 경로에서 FPS 입력과 이후 AI bake·C++ 실행을 확인해요. 렌더 조건을 확인하지 않고 클릭 처리만 반복하지 않아요. 아직 성공으로 기록하지 않아요.

1872 후속: 클릭 때 selection도 소유 트랙 ID로 전환한 뒤 실제 드래그/Undo/곡선 FPS·AI bake·CPP4함수 편집기 검사가 통과했어요(4kjJSW). 렌더 가드와 선택 상태 불일치가 원인이었어요. 최종 TC 눈금·DF 비호환 입력 잠금은 설치 검사에서 추가 확인해요.

1876 확정: 최종 설치 BgeJeM에서 가시 격자 control/TC 눈금·DF 잠금·TC 입력132px 같은 행·드래그/Undo/곡선 열기·CPP4함수와 독립 D3D가 모두 통과했어요. 1872 선택/곡선 진단은 해결됐고 GL 초기 지연 잔여와 구분해요.

## 1909 곡선 제어점 수치 진단

stationary inverse 첫 독립 oracle에서 약3.7e-6 오차를 찾아 centered cubic 분기를 추가했어요. 원래 stationary 오차는 해소됐지만 legacy auto 분할 회귀가 1.9025초에서 -1 vs -0.9990497685로 달라졌어요. 재현: auto scalar keys(0:0,.6:2,1.9:-1,3.3:3,4:4), split[.2,2.6]. 근거는 native/build/diagnose1909-auto.mjs예요. a≈4.4e-16인 사실상 선형 시간 다항식이 절대 discriminant 허용치 때문에 stationary로 오분류되고 root clamp0이 됐어요. 다음 가설: discriminant 절대값 대신 실제 derivative 최소값≈0 조건을 검사하면 stationary oracle와 legacy auto dense outside 회귀를 함께 보존해요. 별도 문제였던 vector 제어점 part(...,channel) 누락은 scalar/vector 독립 oracle로 수정했고, JSON -0은 fixture 직렬화 기대값을 맞췄어요. 품질 허용치를 낮추지 않아요.

1909 UI 좁은 곡선 패널: 기존 weighted 창 회귀가 graph130px 하한을 확인했어요. 최초 keybar162.5/graph100px와 상단31px클리핑을 포착했어요. 단일채널 label행·간격·selector/summary배치를 고친 뒤 keybar122/graph110.0625px로 상단클리핑은 해소됐지만3행이 남았어요. 품질 하한은 낮추지 않아요. 다음은 실제 마지막 행 제어를 확인해 기존 fit/고급 범위 제어 배치를 같은 툴바 안에서 정리하고 최소 graph130px를 복원해요.

1909 해결 확인: derivative 최소값 판별로 stationary와 사실상 선형 시간 다항식을 구분해 새 oracle/기존 dense subdivision 회귀가 함께 통과했어요. 단일채널행·selector간격과 선택개수를 하단에 배치하고 Fit를 하단 조작줄로 옮겨 graph130px 하한을 보존했어요. current weighted-curves-1295-UgpOlP와 curve-controls-1908-window-4Gfa2b 실제창/C++가 통과했어요. 포인터는 수직 핸들의 화면 좌표 양자화 때문에 0.75 CSSpx 시간축 스냅을 사용해 정확히 weight0을 저장해요. 이전 실패는 구현 성과에 세지 않아요.

## 1913–1915 자료형 의존 제작
별도3에셋/생성include/파일CAS/이관7검사통과 후 실제UI에서 record전환 기본값0을 발견. nativeTypeAssetDefault가 기존float value까지핀에 넘겨 nativeRecordDefault의명시값우선에걸림; 새record선언pin으로조회. 독립unit에이전value0회귀추가. 다음창은참조/이관/CPP[99,4,12]/Actor정상이나종료실패; diagnostics는원래내용복원/save후 Stats dirtytrue. applyFileBatch의server noChange분기가finishFileBatch를건너뛰는원인확정. no-op저장도observed/CAS확인후clean뷰확정·새Undo미생성으로수정하고VM/실제창재검사. 실패두창은성과아님.
# 2961–2980 보폭·거리·부분 고정

첫 거리 제약 검사 한 건은 native `componentSetJson`의 인자를 `value`로 잘못 작성했어요. 기존 공용 구현과 Bridge의 `json` 계약을 확인하고 검사 인자만 수정했어요. 엔진 JSON 검증을 약화하지 않았고 실패 실행은 성과에서 제외해요. 최종 final2976: weighted-pins-l9aOgY16·deformable-distance-lhtHOt13·distance-editors-O6NQxA4, 기존 mass brush13/UI5/hot7/distribution14/cloth8 통과. 애니메이션 소스는 group2967의 stride14/ground16/foot14 이후 변경하지 않아 재실행하지 않았어요. 신규47+관련77이며 실제 C++ 재컴파일·GPU/GUI/설치는 0이에요.
# 2983–3000 뷰포트 마우스 명령 조합

최초 소유 app hook fixture에 기존 `saveViewportPreferences` 등록 콜백이 빠져 ReferenceError가 났어요. fixture scope에 그 기존 콜백만 보충했고 실제 앱 코드는 바꾸지 않았어요. 최종 pointer-shortcuts-aeTgev 11건 통과. 같은 묶음의 기존 단축키 199명령 gate·뷰포트 185검사/머테리얼 미리보기 격리 gate는 첫 실행에서 통과해 재실행하지 않았어요. 실제 브라우저의 뒤로/앞으로 기본 동작·분리 창/DPI·화면 픽셀은 검사하지 않았어요.
# 3001–3020 큰 입자 JSON 경로

일반 game JSON 배열4096/노드10000/텍스트262144와 native wire 문자열4096이 다른 층에 있어 단순 서비스 파서 변경만으로는 큰 C++ 배열을 연결할 수 없었어요. 등록된5 입자 속성만 strict schema/토폴로지 예산·NativeProtocol 순서별 사설 검증·C++ enqueue 전 shape 검증으로 연결해요. 일반 제한은 그대로예요. 첫 source fixture는 Rope2D에 미지원 topology 및5000입자를 넣었어요. Cloth rope5000/Rope2D 기존유효4096으로 나누고 규격을 늘려 통과시키지 않았어요. 최종 source11 component-json-bvVx9N, 관련56+nativeinput10/records1478gate 통과. 현재SDK component-json-cpp-xKhzC6 2메서드6호출5queue·65536배열5종/65535tether·4거부/미존재legacy배열·공용재생 통과. 새SDK fingerprint는 WORK3020·과거SDK CPP전체를 현재검증으로세지않아요.
# 3021–3040 작성 고정점 경로 연결

처음 group3026은 새 test fixture의 non-async 거절 callback 안 await를 syntax gate에서 잡아 실행 전에 멈췄어요. fixture만 async로 고친 뒤 runtime 신규21/관련33 통과. 알고리즘 추가 검토에서 유한 행렬×기하 곱과 경로 합의 overflow가 무한 relax를 만들 수 있음을 확인해 유한 축·overflow 경로·all-pinned 결과 검증을 추가했어요. 그 변경 소유21만 다시 실행하여 cloth-tethers-trCuxz 통과, 관련33은 무변경 소유 결과를 보존했어요. 65536격자 작성 생성은 보고서의 실제 Node 시간이며 브라우저/FPS/heap 측정이 아니에요. SDK/바이너리 추가 생성·GUI·설치는 없어요.

# 3402 JSON 행 비교 후보
500개 소유 행·호출당2행변경·120호출·새프로세스3회 비교. 기존 native JSON 151.63ms 중앙값 대비 일반 재귀+descriptor313.54ms, plain-data 재귀175.60ms로 모두 느렸어요. 이 두 후보는 미채택이며 직렬화 행 수 감소를 성능 향상으로 세지 않아요. raw자료 native/build/runtime-sync-4SQgzb. 같은 재귀 후보 반복 금지. 별도 가설은 검증된 engine-owned JSON 구조에 대한 한정 비교 함수를 한 번 만들고 재사용하면 필드별 JS 재귀 호출 비용을 줄일 수 있다는 것이며, 같은 fixture의 실제 CPU·전달값·실패 복구로 반증해요. 기존 임의 JS/브라우저 호출은 그대로 유지해요.

3402 최종: 구조별 한정 비교 코드 재사용 후보는 같은 500행 fixture에서 81.21ms로 통과했어요. 필드 이름 데이터 인용·키 소유 검사·예산 fallback·캐시16·고정 불변 subtree 참조·행 퇴역/실패/reset 수명을 검사했어요. 일반 재귀 비교의 두 실패는 성과에서 제외해요. 물리 정적 캐시도 88.35ms 및 변경/퇴역/복귀 동등성 통과. 기존 물리 gate의 unknown Actor[] 거절은 현재 typed-input 단계에서 발생하므로 fixture가 그 정확한 메시지도 허용하도록 고쳤으며 실제 C++ 질의 gate는 통과했어요.

3416 반증 결과: 동일263자 PE helper --hidden 종료1/19ms, 짧은 경로0/24ms. BeginUpdateResource 일반 긴경로는 정상. C++ filesystem/stream 선행 검사에 extended-prefix를 적용하고 helper 실패는 stdout 대기 GUI 대신 stderr/exit1로 반환. XInput 원인 가설 철회.

3416 긴경로 2차: extended prefix로 선행 검사는 통과했으나 EndUpdateResource가 game metadata write로 즉시 실패. 다음 소유 레이어는 PE 한 파일만 짧은 TEMP에서 기록하고 원래 이름을 보존한 뒤 sibling→원본 원자 교체. 전체 패키징 대신 작은 metadata fixture로 먼저 반증해요.

3416 긴 경로 worker: 실제263자 EXE는 일반 spawn ENOENT·namespaced spawn exit0으로 반증. NativeHost의 Win32 프로세스 경로를 표준 toNamespacedPath로 넘겨 현재 CWD/다른 플랫폼/원본 파일명은 유지해요. 백신 격리라고 추정해 우회하지 않아요.
