# 224 · 선택적인 네이티브 UV 1 정점 스트림

- SceneVertex 48B/기존 JSON stride12 유지·UV1 있는 기하만 별도 float2 정점 버퍼8B/정점·별도slot1과 HLSL UV1 보간·재료용 기초 좌표 전달
- JS packet 선택 배열/형식·길이·NaN 검증·Win32 Bridge의 선택 배열 파싱·UV1 없는 기하는 추가 버퍼 없이 shader0 출력
- 실제 DirectX C++ 프로그램에서 UV0 녹색/UV1 빨강 독립 픽셀·UV1 없는 메시0·다시 원본 메시 그려서 잔류 상태 없음·잘못된 길이/NaN 거부

검증 근거: [기계 판독 기록](research/ENGINE_WORK_224.json).

남은 범위:

- 이 단계는 네이티브 정점 스트림이다. 라이트맵 수신·재료 그래프 채널 선택·광선 재료 UV1은 아직 이어서 연결해야 한다
- 소스 C++ 장치 픽셀 검사는 통과했으며 새 Bridge를 포함한 호스트 재빌드/게임/설치 검사는 다음 베이크 그룹에서 함께 수행한다


223–228 설치 확인: b632ce56672d0c14·명세2764파일 실행후SHA동일·설치본 자체 빌더의 D3D/WebGL/WebGPU 세 게임·UV1 저작/베이크/선형 Half 미리보기·원자 Undo/Redo·AI dryRun/원본SHA가드 통과. 오류0/종료0·캡처3시각확인. User10385파일SHA불변·링크2/.hbproject·Versions1·이전설치192727227B 제거. USER_INSTALL_228.json.
