### 2026-10-06 — P1-6~P2-16·A1~A13 일괄 구현 뒤 통합 검사

P0-5 설치본은 `09e4470b1e254ac3`이다. 나머지 요청을 함께 구현한 뒤 통합 검사와 실패 수리를 진행한다. 원본 게임은 공동 작업 중이므로 고정 사본 `native/build/auric-spawn-LruQRE`와 최신 게임의 별도 사본을 사용한다. 원본 에셋·C++·검사기 원문을 변경하지 않는다.

- C++ 오디오 16종·배경음 4곡, 입력 전 비차단, 헤드리스 소리 기록, 첫 프레임 위젯, UI 변경·5방향 채움·9-slice·애니메이션, 등록 컴포넌트의 자료형/범위 검사와 C++ 읽기/쓰기, 데이터 3개/76개 밸런스 필드·한글 표/Undo·중괄호 배열, 장치 구분·누름 유지, 문서별 카메라·외부 변경·Source 단일 원문·BOM/줄바꿈 정규화, 정수 배율·타일 반복·Y 정렬, 투사체 배열/인스턴싱을 공용 실행 경로로 연결했다.
- A4/A5: 첫 Spawn의 C++ Construction 시 후속 객체가 아직 VM에 없어 worker에서 제거되던 문제를 공용 연산 적용에서 전체 생성 객체를 먼저 등록하는 방식으로 수정했다. 실제 C++ 헤드리스·편집기·Game.exe·Android에서 생성93개/Construction93회/다음 프레임 포인터/HP99.25 확인. `native-spawn-UgDO4M` 실패 재현과 `native-spawn-yiRsAZ` 성공을 보존했다.
- A2/A3: JSON/이미지 원본 캐시·템플릿 준비·단순 풀 객체의 불필요한 컴포넌트 재시작 제거. 실제 Game.exe `features-window-Xsn7PR`의 준비된 PF_Slash 최초 생성0.20ms, 40회 생성p95 0.10ms, 풀 획득p95 0.10ms. 엔진 연산 내부 CPU 시간이며 C++ 왕복·명령 대기·GPU 컴파일을 포함하지 않는다. 0ms 표본은 시계 해상도 아래의 값이다.
- A6: 실제 C++ FSM·행동트리 5개×3프레임의15→3왕복. 블랙보드 변경·전환·FinishTask·실패·서비스·병렬·재평가 경계는 실행 순서를 보존한다. `state-native-batch-0dNLM4`, `behavior-native-batch-ZRRnTx` 성공.
- A1: 직렬화/patch/Ack, worker parse/sync/checkpoint/invoke/snapshot, 프런트 상태/연산 적용/전체 시간을 구분한다. `editor-window-TQFwe6/native-profiler.json` 실제 기록. 제출된70~90ms와 고정 사본은 게임 버전이 달라 통제된 전후 비교로 표시하지 않는다. 보스방/빈 방 새 측정은 통합 검사에서 수집한다.
- A7: 실제 편집기에서 활성 BP 문서를 보면서 Play 시간 진행, pauseReason/진행 상태 확인. A8 경로만 nondirty 빌드, A9 공개 속성512개/원인별 오류, A10 중복 이름/ID의 구체 오류를 연결했다.
- A11~A13: PostProcessVolume의 전역 블룸(임계값/세기/반경/해상도), Sprite/Tilemap 발광 강도, 가산 혼합, Sprites::Flash/PlayAnimation. 간접조명/GI 지원을 뜻하지 않는다. `2d-effects-window-jQIv7R` 실제 C++ 재생/반복/정지·흰 번쩍임·경계 밖 블룸·높은 임계값·검은 여백·GPU 끄기/켜기5회 성공(텍스처2개 유지). 블룸 비활성 상태에서는 후처리 버퍼를 만들지 않는다.
- Android `android-window-DGHFci`: Spawn93/Construction93/HP99.25, 오디오20개·터치·백그라운드/재개,1000발/적30개600프레임 평균39.7923fps/VM작업p95 30.3ms. 마지막Back 실패로 전체 성공은 아니다. Android16/target36은 onBackPressed를 호출하지 않아 API33+ OnBackInvokedDispatcher로 수정 후 재검사한다. x86_64/4코어/호스트RTX4070SUPER 에뮬레이터이며 중급 실기기 결과가 아니다.
- `kiosk-watchdog-7pB3zg`: 검증 전용 Game.exe의 경로/PID/인자를 확인하고 실제 강제 종료→1초 후 새PID→실행 준비→정상 종료 시 재실행 없음 성공. 사용자 앱/기본ADB 미변경.
- 실제8시간 `kiosk-soak-zEjNdw`: 시작UTC05:45:40.467, 목표UTC13:45:40.467. 가속 실행으로 대체하지 않는다. 워밍업 중 누적 프레임에 의한 준비 판정 오류는 측정 게이트만 보정하고 `sampling-readiness.json`에 시각/이유를 기록했다. 게임 코드/렌더러/프로세스/8시간 시계는 유지했다. 종료 전 통과 표시 금지.
- 최신 원본 검사기SHA256 `976c8f545aaf58cfac8b2dc5a06857202bf2c073548bef757e65338a2794d891`는 공동 작업에서 변경됐다. 예전 고정 검사기 `55e77b195642b74fc61d1646be3caff641309f87d7332e1f7a1f0063a2958de3` 원문을 보존하고9개 성공(`checker-tdWbin`). 최신 게임/검사기는 별도 사본으로 검사한다. 검사기의 옛 키 해제 전제는 골든 결과 비교에만 `preserveInputOnTravel:false` 호환 옵션을 적용한다. 누름 유지 자체는 별도 편집기/배포/헤드리스 검사로 검증한다. 검사기 원문을 수정하지 않는다. 헤드리스 호환 어댑터는 `AURIC_MUTE` 환경변수를 제거하고 소리 기록도 남긴다.
- 감속3→2.4m는 계수0.8일 때다. 원본0.75는2.25m를 보존하고 데이터만0.8로 바꾸면 재컴파일 없이2.4m가 되는 것을 확인했다. 검사를 맞추려고 원본 밸런스를 변경하지 않았다.

실물 Android의10분 발열/터치 지연, 실제 iPhone/TestFlight 서명, 실제8시간 완료는 미검증이다. Mac/Xcode·Apple 서명 자료·연결된 테스트 휴대폰이 없는 현재 환경에서 에뮬레이터나 짧은 실행으로 해당 항목을 완료 처리하지 않는다. 나머지 통합 결과 확인 후 한국어 커밋/푸시·불변 사용자 설치본 갱신을 진행한다.

근거: [Three.js UnrealBloomPass](https://threejs.org/docs/pages/UnrealBloomPass.html), [Unreal Emissive 입력](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-the-emissive-material-input-in-unreal-engine), [Unity 2D 제작 흐름](https://docs.unity3d.com/6000.1/Documentation/Manual/2d-game-creation-wokflow.html), [Android16 Back 변경](https://developer.android.com/about/versions/16/behavior-changes-16#predictive-back).

### 통합 검사 후속 수리

- `auric-features-batch-WVwsTK`에서 headless/원본9개/공용 회귀/2D 실제 창/편집기/Android가 통과했다. PC 성능이58.9281fps로59fps 게이트를 통과하지 못해 전체 batch는false다. 이 실패를 다른 성공으로 덮지 않는다.
- `editor-window-qSHOOF` 실제6초/300프레임 측정: Dungeon_2 프런트 호출p95 2.5ms/왕복p95 1.2062ms, Dungeon_4 프런트p95 2.7ms/왕복p95 1.3707ms, 사용자 invoke p95 .2423ms. 콜백·직렬화·적용의 구간별 수치를 boss-cost.json에 보존했다. 초기 보고에 빠져 있던 편집기 frontendMs를 실제 측정으로 채웠다. 다른 버전의70–90ms와 통제된 전후 비교가 아니다.
- `android-window-GWQQIo`는 Back 두 번의 일시정지/재개까지 통과했다. 1000발·적30개600프레임 평균40.9054fps/작업p95 32.8ms다. 이후 오디오 정리 수정과 Android HUD 세 해상도의 최신 APK 재검사는 별도 기록한다.
- `kiosk-soak-zEjNdw`는 UTC06:13:27.472에 취소했다(마지막1636.159초/28세션). 자연 메모리 증가가 확인되어8시간 통과로 세지 않는다. Heap에서 HTMLAudio 반복 재생의 pending activity→ended 콜백→이전VM 경로와 이전 BlueprintRuntime/AudioContext26개를 확인했다. 공용 disconnect에서 pause/src 해제/load를 수행하고 시작 요청의VM 참조를 성공 직후 해제했다. 이전 실패·heap 증거는 유지했다.
- 실제 Game.exe `features-window-lAHd9Z/audio-lifetime.json`: 음악이 재생되는20회의 실제F12 초기화 뒤 살아 있는 BlueprintRuntime1→1, AudioContext1→1이다. queryObjects의GC를 사용한 수명 회귀 증거이며 자연8시간 메모리 검사와 구분한다. 해당 창은 기능·수명을 통과했지만 PC58.9177fps여서 전체 성공은false다. 앞의`oCueHa`는 검사에서 prototype 조회 대상이 잘못되어0개가 반환된 실패이며 성공으로 쓰지 않는다.
- 투사체에서 요청 대상이 아닌 Collider의 변환 계산과 broad-phase 전에 만들던 매발 이전 위치 배열을 제거했다. 충돌 자료형·swept 판정·hit 순서는 유지하고 공용 런타임 검사가 통과했다. 최신 실제 PC 성능과 자연8시간 검사는 수정 패키지를 따로 측정한다.

- 실제 CPU sampling `features-window-Shu686/cpu-profile.json`에서 HUD updateLayout/clientWidth/matchMedia 비용을 확인했다. 위젯 노드·이미지의 속성/slot·부모 활성·장치 표시·배율이 같으면 DOM 쓰기를 생략하고, 포인터 표시를 한 MediaQueryList로 조회한다. 임의 정지나 성능 임계값 변경을 사용하지 않았다.
- `features-window-D3vnwR` 실제 PC600프레임 평균59.5085fps로 같은59fps/작업p95≤16.667ms 게이트를 통과했다. `ui-render-window-S84vhZ` 실제 정적HUD400ms DOM변경0,6개해상도/DPI/1920×1080 SVG1.5배 직접 SVG와 픽셀 비교/한글/버튼/BP를 통과했다. 수정된 같은 UI 경로를 모바일도 사용한다.
- 새 자연8시간 `kiosk-soak-zjUtGE` 시작UTC06:25:27.387/목표UTC14:25:27.387. 수정된 불변D3vnwR 패키지, 컴파일러 없는PATH, 전용UserData/TEMP/LOCALAPPDATA,60초 무입력 세션 초기화,1000발/적30개 조건이다. 초기 장면의5초 후에만 샘플하며 자연GC를 강제하지 않는다. 이전 두 취소 검사는8시간 성공에서 제외한다.

- 최신 원본게임537파일의 사본/원문검사기9개는 `checker-ADsL1K`에서 통과했다. 현재 checker976c8f...·원본게임·격리엔진 사본SHA를 보존했고 AURIC_MUTE 환경변수는 사용하지 않았다. 옛 검사기의 장면 전환 key-release 전제에는 검사 어댑터의 명시적호환옵션만 적용했으며, 실제 누름 유지 증거와 분리했다.
- 최신 Android APK `android-window-zoYaCZ`는 설치/Activity시작 뒤 전용ADB장치 연결이 사라져 실패했다. 게임성능/새HUD해상도 통과 증거로 계산하지 않는다. 같은APK를 새 전용기기에서 재검사하며 사용자ADB5037/프로필을 변경하지 않는다. 실물 USB 기기조회 결과는0대였다.


### 2026-10-06 — 사용자 설치본 반영 및 모바일 통합 후속

- 한국어 커밋 2dfdb89를 공개 HBEngine/main에 푸시했고, 사용자 설치본을 **C:/Users/kirby/HBEngine/Versions/fddd827f41717173/HBEngine.exe**로 갱신했다. 1,721파일과 주요 런타임/API/Android 소스 SHA를 설치 후 대조했다. 기존09e4470b1e254ac3·사용자 프로필·실행 중인 앱·기본ADB5037을 보존했다. 새 실행부터 적용된다. 설치 증거: engineCreate/native/build/auric-user-install-20261006.json.
- P1-7의 두 완료 기준을 체크했다. 실제 편집기 p6kXQ2·Game.exe Xsn7PR 및 최신 Android jbIuSt/ufqJHJ의1280×720/1920×1080/2340×1080 HUD에서 중복 요소 없는 피로도1·선택테두리1·공격버튼1·한글을 확인했다. Android는 실제 WebView를 CDP로 리사이즈했으며, 실제 휴대폰 화면 검사가 아니다. Actor BeginPlay 전 준비된 WidgetReady와 즉시 HUD 호출이 성공했다. 별도 모바일 성능 실패를 이 기능 성공으로 덮지 않는다.
- 최신 APK jbIuSt/ufqJHJ의1,000발/적30개 성능은 각각28.3683/29.1622fps, 작업p95 48.4/46.8ms로 실패했다. ufqJHJ에서 원래806×456/DPR1.5 복원 뒤 측정해 단순 미복원 화면 크기 가설을 제외했다. 이전GWQQIo의40.9054fps 결과와 분리하며 C++ 처리/응답 대기 및 PC8시간 동시 실행 조건을 분석한다. 게이트30fps/p95≤33.333ms는 유지한다. 오디오20·생성93·세HUD해상도·터치·HOME복귀·Back 두번은 동작했다.
- 새 iOS 원격 검사37424160740은 Xcode 앞의 공용 검사에서 실패했다. P2-11의 Source 단일 원문 계약으로 외부 변경을 읽도록 고쳤는데 옛 검사가 외부 변경을 거절하라고 검증한 문제다. 새 검사는 컴파일러 인자의 수정된 Source·BOM/줄바꿈 정규화·공유1회 컴파일·이전 실행/저장BP의 불변성을 검증한다. 로컬 통과 후 다시 원격 빌드한다. 이 실패는 새 iOS 통과로 계산하지 않는다.
- 자연8시간 zjUtGE는 계속 실행 중이다. 검사 전용 프로세스 트리만 BelowNormal 우선순위로 바꿨고 background-priority.json에 PID/생성시각/이유를 보존했다. 사용자 앱을 건드리지 않았고 실행 코드·8시간 시계·메모리 게이트는 변경하지 않았다. 워밍업30분과 실제8시간 완료 전에 완료 체크하지 않는다.

- iOS 사전 공용 검사의 headless 단계에서 종료된 Actor의 InputActions 키가 남는 문제를 발견했다. LevelTransition은 공유 장치 상태와 지속 GameInstance 입력을 유지하고, 떠나는 Actor의 키/이전 액션 상태는 해제하도록 공용 stop을 수정했다. 실제 C++ 장면 전환 뒤 새 월드 d=1 유지·옛 Actor 키0·GameInstance 입력1, 기존 타이머/지연 취소·원본 장면 보존 검사가 통과했다. 사전 그룹 gfZK8B의 앞7개와 수정 headless, tail77GWUM의9개가 통과했다. 새 iOS SDK 결과는 별도 수집한다.
- Android aY0HKH는 HUD 리사이즈를 생략하고 CPU sampling을 켠 진단이며17.9840fps/p95 72.9ms로 실패했다. C++ 사전 컴파일과 PC8시간 실행이 겹쳤고 sampling 비용도 들어 있어 일반 성능 결과로 확대하지 않는다. 33.883초 프로필 중 idle18.141초·program3.259초, 네이티브 왕복 평균6.958ms/worker2.876ms를 기록했다. 다음 측정은 대량 컴파일과 sampling 없이 진행한다.

- Android 진단 aY0HKH/dU0emM은 실행 환경 지정이 빠져 실제2코어0–1/SwiftShader로 실행됐다. 4코어0–3/RTX4070SUPER인 GWQQIo·jbIuSt·ufqJHJ와 통제된 비교가 아니다. dU0emM20.1321fps/작업p9563.4ms도 일반4코어 성능 회귀로 계산하지 않는다. 원래4코어 호스트 GPU의 최신 실패2개는 유지한다. 실행 조건을 다시 명시한 최신417f384 APK/전체 모바일 검사를 진행하며 진단 환경 기록을 바로잡는다.


### 2026-10-06 — iOS 원격 통과와 프레임 대기 후속

- 공개 main의417f384 iOS 원격37425093439가 성공했다. 실제 두 Xcode SDK 컴파일·독립 iPhone SE3 시뮬레이터 설치/실행·C++ 두 모듈·물리·에셋 범위·반복 오디오 신호·배경 음소거와 복귀 후 재생/월드 보존을 통과했다. 원격 ios-mobile-proof를 다운로드해 native/build/ios-proof-37425093439에 보존했다. 실제 청취·실물 기기·서명 검증은 false다. TestFlight 절차와 원격 Mac/Apple 서명 자료의 경계는 docs/IOS_REMOTE_DISTRIBUTION.md에 정리했다.
- 타이머 없는 독립 C++ 모듈의 frame 응답 대기를 함께 수행하는 공용 경로를 추가했다. 외부 모듈 호출·진행 중 요청·밀린 frame·float32 오버플로·타이머 콜백이 있으면 순차 경계를 유지한다. 실제 C++ 두 모듈의 float32 시계, 콜백의 배율 변경/Spawn/Stop 순서, 기존 frame/transport/headless/runtime/GameInstance 검사가 통과했다.
- 실제 PC features-window-k9VzZd의전체기능/600프레임59.31198fps가 통과했다. 새 Android5XetDR는 실제4코어0–3/호스트GPU에서 생성93·오디오20·세HUD해상도·터치·HOME·Back이 동작했으나32.2485fps/작업p9542.9ms로 전체성능 게이트에 실패했다. 기준을 낮추지 않았다. 최근120호출의worker평균.8435ms/왕복5.2ms를 근거로, Android 공식Handler callback에서메시지를받게수정하고새APK로검사한다.


### 2026-10-06 — 프레임 안전 경계와 배포 준비

- 별도 Android 메시지 스레드 실험 d9CjKs는 실제 background callback·기능을 확인했으나30.6455fps/작업p9545.6ms로 실패했다. 개선 근거가 없어 해당 Java 변경과 전용 검사 변경을 제외했다. 기존 기본ADB와 사용자 창은 보존했다.
- q82C5Z는 기본 메시지 경로와 반환된 외부 모듈의 시계·타이머 증명을 사용한 APK다. 전체기능은 동작했으나31.5224fps/작업p9544.4ms로 예산 실패다. 게이트를 변경하지 않았고 성능 개선 완료로 계산하지 않는다. 후속 원격 호출이 타이머 상태를 바꿨을 때 오래된 진행 중 응답이 증명을 복원하지 못하도록 revision 경계를 추가했고, 실제 C++·통신·장면 전환·GameInstance 회귀가 통과했다.
- 프레임 그룹의 parallel/sequential 횟수를 기존 runtime.state·Player 검사·headless 결과에 별도 기록한다. 마지막 C++ 호출의nativeTiming이 덮어써지는 것과 분리했다. 앞 APK에는 이 최종 진단 필드/늦은 응답 보호가 모두 들어 있다고 주장하지 않는다. 새 설치본·iOS 원격 검사는 고정한 최종 소스로 만든다.
- 최신 원문 검사 checker-UFabo8은9개 통과/code0,537파일·검사기976c8f…·격리게임·격리엔진SHA를 보존했다. 실제 Editor 검사에서 남아 있던 AURIC_MUTE=1도 제거해 직접 오디오 경로를 검사한다. 자연8시간 zjUtGE의 코드·시계·게이트는 변경하지 않고 계속 기록한다.


### 2026-10-06 — 448a9b5 사용자 설치본 갱신

- 공개main에 한국어 커밋448a9b5를 푸시하고, 최종 Windows 배포본을 C:/Users/kirby/HBEngine/Versions/42bcd763ffa422e3/HBEngine.exe로 옮겼다. 바탕화면 HBEngine 사용자용.lnk는 새 버전을 가리킨다.1,723파일의 설치 SHA와 주요 실행/API11파일을 현재 소스와 대조했다. 이전fddd827f41717173과09e4470b1e254ac3·사용자 프로필·열린 앱을 보존했다. 새 실행부터 적용된다. 증거native/build/auric-user-install-448a9b5.json.
- editor-window-Zg11qp는 AURIC_MUTE 없는 실제편집기에서 통과했다. Source 단일 원문·93생성·20소리·데이터/Undo·문서 외 실행·누름 유지 등의 공용 실행을 확인했다. 최종늦은응답 보호와횟수진단은448a9b5의 별도 C++회귀/새iOS원격 검사에 연결했다.
- 설치 완료는 Android 성능·실물기기·자연8시간 완료를 대신하지 않는다. Android의최종448a9b5 APK와같은소스iOS원격 검사를 진행하고, 자연8시간zjUtGE는 기존불변패키지로 계속측정한다. MD와누적엔진 작업의미검증 항목은성공으로표시하지않는다.


### 2026-10-06 — 최종 Android 실행·성능 통과

- 설치본과 같은448a9b5의 새 APK android-window-xDeGsX가 전체 검사를 통과했다. 실제4코어0–3·x86_64·호스트RTX4070SUPER 에뮬레이터,1,000발/적30개600프레임 평균43.26351fps·작업p9530.1ms·렌더p951.0ms다.30fps/작업p95≤33.333ms 기준을 유지했다. 프레임 그룹parallel888/sequential0을 기록하여 최종 공용 경로가 실제 앱에서 사용됨을 확인했다.
- 생성93·Construction93·다음프레임HP99.25, 소리20개,1280×720/1920×1080/2340×1080 HUD, 원래806×456/DPR1.5 복원, 터치,HOME정지/복귀,Back2회 일시정지/재개를 함께 통과했다. 앞의 모든 실패는 유지했다. 이 결과는중급실물기기·발열10분·스피커청취 증거가아니다. P2-16의실기기 기준은미체크를유지한다.
- 별도 메시지 스레드는제외된최종기본메시지 경로다. 독립모듈 프레임대기·외부시계증명·늦은응답보호의최종코드를검사했고, Windows 설치본42bcd763ffa422e3의런타임과일치한다. 같은최종소스iOS37427806194와실제PC최종검사가계속된다.

### 최종 설치 소스의 PC·현재 게임·iOS 결과

- `448a9b5`의 실제 Game.exe `features-window-Av9j2H`가 전체 기능을 통과했다. 1,000발·적30개·600프레임 평균59.500788fps, 작업p95 10.5ms, 렌더 제출p95 .6ms이며 기존59fps/작업p95≤16.667ms 기준을 유지했다. 생성93/Construction93/HP99.25,20개오디오,3개HUD해상도,6장면,장면전환W누름2.125m,F12/60초리셋을 함께 확인했다. 준비된최초생성 .20ms/반복p95 .20ms/풀획득p95 .10ms는 연산 내부 CPU 구간이다.
- `checker-qfTJah`는 최신게임537파일 사본과 원문 `check_demo.mjs`9개를 통과했다(code0). 원본게임·검사기·격리게임·엔진사본SHA 보존을 확인했다. 검사기SHA976c8f…이며 키해제 전제의호환옵션만사용했고 AURIC_MUTE는없다.
- 같은소스 [iOS37427806194](https://github.com/kirby47navercom-ai/HBEngine/actions/runs/37427806194)도 성공했다. 아티팩트11396326248을 `native/build/ios-proof-37427806194`로 내려받아 결과본문을 확인했다. 공용C++검사,두Xcode대상컴파일,iPhoneSE3시뮬레이터 설치·실행,두C++모듈,물리질의,미디어범위요청,반복오디오신호,배경정지·음소거/복귀월드·재생이통과했다. `audioHeard/physicalDeviceVerified/signingVerified`는false다. 실제Auric iOS배포본·TestFlight·실물청취 증거로 확대하지않는다.
- 설치본42bcd763ffa422e3는 위최종런타임을포함한다. 이후검사기록만추가하는문서커밋때문에 사용자설치본을다시변경하지않는다.
- 자연8시간zjUtGE의약52분 표본에서JS살아있는heap은약28~52MiB로순환하지만전체private메모리는워밍업후1146→1375MiB로증가했다.8시간완료/메모리안정통과로표시하지않는다. 불변검사는유지하고 별도 `memory-controlled-GG4TUO`에서활성실행/Runtime진단활성여부/일시정지를비교한다. 강제GC없고 사용자프로필·창은사용하지않는다.

### 노치 안전 영역

`ui-render-window-J43YYZ`는 기존6화면/DPI/SVG1.5배/한글/클릭·BP·터치 검사에 실제 CSS 환경 변수의노치3조건을추가해통과했다.2340×1080에서좌우84/72·하단24px,상단32·하단24px,0으로복원했으며safe-area컨테이너·HP·공격버튼좌표가예상값과 .1px이내로일치했다. 원본위젯불변·정상종료0·서버종료도확인한뒤acceptance를저장한다. 사용법은 `node tools/check-ui-render-window.mjs --cutouts`다. [공식CDP프로토콜](https://github.com/ChromeDevTools/devtools-protocol/blob/master/json/browser_protocol.json)의experimental `Emulation.setSafeAreaInsetsOverride`를사용했고실물노치를검증한것은아니다.

Auric최종APK의landscape·Back/HOME실행과최종iOS의배경정지·오디오재개및landscape출력계약에함께근거하여 MD의해당기능기준을체크했다. 실제휴대폰·서명/청취·8시간·실물중급탄막성능은계속미검증이다.


### 2026-10-06 — 반복 효과음 측정 버퍼와 장시간 진단

- 공용 AudioRouting의 Analyser를 유휴 최대16개로 재사용하고, 이전 파형을 오디오 시계 기준으로 비운 뒤 새 재생에 연결한다. 종료 시 유휴 연결도 정리한다. 최초 단순 disconnect 구현의 실제 강한/약한 소리 혼입 실패(features-window-iXrtCr)는 보존했다.
- 실제 Windows features-window-cSnRHl은 .8/.02 진폭의40ms PCM12회에서 새 Analyser1개·peak오차.005이내를 통과했다. 기존93생성/20소리/3HUD해상도/6장면/W누름/F12/60초 초기화와1,000발·적30개600프레임도통과했다(59.596531fps/작업p959.5ms).
- 자연GC·같은GameInstance의 별도 memory-controlled-egPsS8 약6분대조에서 크기524,284바이트의 샘플 할당은123초/248초 뒤1개/1개다. 기존 bOMG23은53개/105개, PCM JhXfdi는54개/106개였다. 샘플 바이트를 전체메모리나누수량으로세지않고 초기사용량이서로다른프로세스를단순차감하지않는다. Analyser제거대조 mbH9a3은0개였지만 측정을뺀진단이며제품합격증거가아니다.
- Android hQrbsx의첫40ms진단은새오디오장치시작전벽시계60ms로읽어0을반환했다. 기존20게임소리는정상이며실패를보존했다. 검사시간을실제AudioContext시계로측정한pEDhFS에서는12개신호/새노드1개와93생성·20소리·HUD·터치·HOME·Back이동작했다. 그러나600프레임33.556484fps/작업p9541.6ms로기존p95≤33.333ms게이트에실패했다. 전체성능합격으로계산하지않는다. 같은APK에서지연원인을분리하고있다.
- iOS도같은12개신호검사를실제WKWebView진단에연결했다. 새원격SDK/시뮬레이터결과는아직수집전이다. 실물·서명·스피커청취는기존처럼미검증이다.
- 불변자연8시간zjUtGE는코드·시계·게이트를유지하고계속실행한다. 마지막5,829초/97세션의전체private1,926.21MiB/JSheap37.07MiB로전체증가가남아있다. 이번버퍼변경이들어간패키지가아니며8시간안정통과체크를하지않는다.
- 공식Chromium의고정커밋에서Analyser관련8파일을전부읽고본문SHA·범위·설치버전미대조를docs/research/AUDIO_ANALYSER_LIFETIME_028.md에구분했다. 전체Unreal/Unity분석완료로승격하지않는다. 원본게임/검사기는수정하지않고열린사용자엔진·프로필·기본ADB를유지한다.

### 2026-10-06 — 오디오 유휴 비용 보강·플랫폼 결과 구분

- 공용 오디오 측정 노드는 이전 신호를 비운 뒤 처리를 멈추고, 활성 소리/정리 중인 노드가 없으면 타이머도 종료해요. 공간 좌표는 바뀐 축만 예약해요. 재사용·정리·움직임·원본 배열 변경·믹서/소리 회귀가 통과했어요.
- 실제 Windows `features-window-PVSo1Z`: 전체 기능/1,000발·적30/C++600프레임 59.404176fps, 작업p95 11ms, 12개 강/약 신호와 생성1개·유휴 연결 해제·타이머 종료 통과예요.
- 직전 a3ad7ec iOS run37433705272: 두 SDK 컴파일/별도 시뮬레이터/12개 신호·생성1개·배경 정지·복귀 통과예요. 실제 기기·청취·서명은 미검증이며 후속 유휴/좌표 변경과 같은 소스는 다시 원격 확인해요.
- 최신 APK `android-window-lcqWUQ`는 빌드·설치·Activity 시작 뒤 ADB runtime probe와 WebView 연결에서 시간 초과예요. 성능이나 기능 통과로 계산하지 않고 실패 증거를 보존해요. 동일 APK로 연결 경로를 진단하며 기존 성공/예산 실패 수치는 지우지 않아요.
- 자연 GC 대조 XAZtAi는 청취 좌표 예약 포함/생략 구간 123.716/124.056초, private588.75→663.20/666.20→662.50MiB예요. 자연 GC·구간 초기값 차이가 있어 단독 원인이나 장기 안정성 판정이 아니에요. 기존 D3의 실제8시간 검사·원래 기준은 유지하며 메모리 증가를 계속 추적해요.
- 상세 원문 범위/hash·한계는 `docs/research/AUDIO_IDLE_COST_029.md`예요. 분석 전체 완료/실기기/8시간 체크박스는 올리지 않아요. 기존 사용자 설치/프로필/열린 창과 원본 게임을 보존해요.


### 2026-10-06 — 오디오 보강 522dba1 설치·동일 소스 플랫폼 확인

- 공개 main의 한국어 커밋522dba1을 Windows 사용자 설치 C:/Users/kirby/HBEngine/Versions/d9f5d903ff35b9d6/HBEngine.exe로 갱신했어요. 바탕화면 HBEngine 사용자용.lnk도 새 버전을 가리켜요.1,730파일 설치와 실행/API/오디오13파일의 소스 SHA를 대조했고 이전42bcd763ffa422e3·프로필·기본ADB14204를 보존했어요. 새 실행부터 적용돼요. 증거 native/build/auric-user-install-522dba1.json. 설치 후 증거 수집의 PowerShell 단일 객체/배열 처리 오류는 바로잡고 같은 불변 버전 재검증으로 기록했어요.
- 현재 원문 게임 검사 checker-lAcd9y는9개/code0 통과, 원본537파일·검사기 SHA976c8f545aaf58cfac8b2dc5a06857202bf2c073548bef757e65338a2794d891·격리게임·엔진 SHA를 보존했어요. 원본 게임과 에셋은 공동 작업 중이므로 덮어쓰지 않아요.
- 같은522dba1 iOS 원격37435591708의 실제 아티팩트를 열어 두SDK컴파일·별도 iPhoneSE3 시뮬레이터 설치/실행·C++/물리·에셋 범위·12개 강/약 신호/생성1개·유휴 연결 해제/타이머 종료·배경 정지/복귀를 확인했어요. 실제 기기·서명·스피커 청취는 false예요. 전체 Auric 원본 게임의 iOS 검사를 대신하지 않아요.
- 같은 APK의 bounded Android 재연결 kJxme8은 생성93·오디오20·12개 신호/유휴 종료·터치·3HUD해상도·HOME/Back을 통과했어요.1,000발/적30개600프레임31.782354fps·작업p9543.1ms로 p95≤33.333ms 예산에 실패했어요. 연결 실패lcqWUQ와 이전 성능 실패를 보존하고 기준을 낮추지 않아요. 탐색 과정을 최대24개 기록하는 진단만 검사기에 추가했어요.
- 최신 고정 Windows 패키지 PVSo1Z의 실제8시간 HjSnC6은 UTC08:25:57→16:25:57(한국 시간10월7일01:25:57)로 새로 측정해요. 이전D3의 zjUtGE는 UTC06:25:27→14:25:27로 그대로 계속해요. 두 검사 모두 강제GC·시계 가속·기준 변경 없이 자연 실행이며 사용자 창/프로젝트를 변경하지 않아요. 기존 검사에서 메모리 증가가 남아 있어 안정성 체크를 올리지 않아요.
- MD의 미체크3개(실물Android 발열/터치/30fps,실제8시간 메모리,PC60fps/중급Android1,000발)를 유지해요. 설치 갱신 후 누적2D전용 그림자의 공식 Unity6000.0/URP17.0.4 API와 동일 버전 공식 렌더 소스 분석을 이어가요. 전체 엔진/전체 문서 분석 완료로 계산하지 않아요.


### 2026-10-06 — 2D 전용 그림자·C++/블루프린트 연결 및 사용자 설치 갱신

- 공식 Unity6000.0/URP17.0.4 Graphics 고정 커밋의22개 렌더/형상/그룹 소스를 본문 SHA와 읽은 범위로 기록했어요. 전체27개 문서 계열의 조사 완료로 올리지 않았어요.
- 알파·SpriteSkin 변형·충돌/타일 충돌·편집 모양·None, Cast/Self/Both/None, 최상위 부모 그룹·정렬 레이어를 전용2D 그림자와 연결했어요. 씬/BP 형상 초안·Undo/Redo·저장, C++15개 함수와 같은 선언의 BP 노드, AI 스키마/배치 목록을 추가했어요. 정지한 그림자 맵은 다시 그리지 않고 미사용 자원을 해제해요.
- 실제 전체 에디터0wPgCZ의 편집/원본 보존 검사, 최종 에디터hfoGkE·배포Player oAxqTM 각각116개/조명·그림자67개 GPU 검사와 실제C++/BP 출력 핀을 통과했어요. 마지막 보강에는 픽셀 가로/세로 크기가 다른 거리 수축과 중복 메시 면 처리가 포함돼요.
- 공개 한국어 커밋c0ed468ee0b716bec000e6bcc9364dbb5b4df5ad를 사용자 C:/Users/kirby/HBEngine/Versions/6a8cfef398a04ea4/HBEngine.exe로 갱신했어요.1,733파일/14개 실행·API파일 SHA 일치, 이전d9f 버전·프로필·열린사용자창46816·기본ADB14204 보존을 확인했어요. 바탕화면 바로가기는 새 버전이며 다음 실행부터 적용돼요. 증거 native/build/shadow-user-install-c0ed468.json / docs/TWO_D_SHADOWS.md.
- 기존522의 Windows/Android/iOS/8시간 증거를 새 그림자의 모바일 검증으로 바꾸지 않아요.8시간 검사는 고정된두 패키지에서 강제GC 없이 계속되며 최신HjSnC6 종료는 한국시간10월7일01:25:57이에요. 마지막2,309초/39세션 private1,249.68MiB,오류0이지만 메모리 증가가 남아요. MD의 실물 모바일/8시간/최종성능3개 체크는 유지하고 전체엔진 기능 작업도 이어가요.


### 2026-10-06 — 렌더 자원 소유권 수정과 동일 게임 사본 대조

- 도형의 고유 자원은 오브젝트, 공유 머테리얼은 제작기, 외부 전달 머테리얼은 호출자가 소유하도록 에디터/Player 수명 관리를 연결했어요. 자식 Actor를 보존하고 광원 그림자 맵도 해제해요.
- 실제 에디터118개/Player117개 GPU 검사 오류0. 동일 GPU에서 수정 전20장면 머테리얼 참조9→369, 수정 후9→9이며 지오메트리/텍스처도 유지돼요. 실제 Auric 기능 통합 Py2rT4는1,000발·적30/600프레임59.509fps/작업p9512ms,93생성/20소리/3HUD해상도/6장면/입력/F12/60초 초기화 통과예요.
- 현재 원문 검사기 SHA c2609e75…의 격리 사본 pMImZr는 웨이브2 해골6마리 처치 실패예요. 같은 사본/생성API로 수정 전4e3ea51을 실행해 같은 실패를 확인했어요. 원본 게임/검사기는 수정하지 않았고 전체 검사 통과로 표시하지 않아요.
- 8시간 검사는 기존 두 고정 패키지에서 계속돼요. 이번 수정의8시간/전체메모리/실물Android 성능 통과로 바꾸지 않으며 미체크3개를 유지해요. 별도 최신자원 수명 진단 VzfhAY는 자연GC/native샘플로 시작했어요. HeapProfiler 샘플 조회 자체가 고정 V8 소스에서 강제GC를 호출하므로 장시간 검사에 추가하지 않았어요.

- 설치 후속: 공개 커밋 c984007을 C:\Users\kirby\HBEngine\Versions\246f76451dd330eb/HBEngine.exe로 갱신했어요. 1737파일과16개 실행/API/문서 해시를 확인했고, 기존6a버전·프로필·사용자창37444·기본ADB14204를 보존했어요. 바탕화면 바로가기는 다음 실행부터 새 버전이에요. 증거 native/build/render-resource-user-install-c984007.json.


### 2026-10-06 — 반복 스트리밍 오디오 수명과 믹서 예약

- PC 공용 재생은 HTMLMediaElement/source를 재사용하고 재생별 핸들·종료 이벤트를 격리해요. 긴 음악의 스트리밍과 모바일의 기존 PCM/32MiB 보유 캐시를 유지해요. 믹서9개 값도 변경될 때만 예약해요.
- 수정 전200회/source200개 실패를 재현했고, 수정 후source1개·동시 재생·옛 핸들/이벤트·늦은play·미연결 종료와 기존UI/C++/믹서/버퍼 검사가 통과했어요. 실제Windows fPV6Zw도 스트리밍12회/source1·옛ended0·강/약 신호와20개 소리/3HUD/93생성/6장면/입력/F12/60초를 통과했어요.1,000발/적30개600프레임은59.404764fps예요.
- 자연GC 대조와 현재수정 메모리 측정은 별도로 기록해요. 기존두8시간 검사는 기존 고정 패키지에서 계속되며 이번 수정의 장기 통과로 바꾸지 않아요. 실물Android·8시간·최종PC/실물30fps 미체크3개를 유지해요. 원본게임/검사기는 수정하지 않았어요.
- 고정Chromium6원문 전체 읽기/SHA/실제 범위를032에 기록하고6주소를 발견 대기열에 추가했어요. 설치Edge revision 일치와 전체corpus 완료로 승격하지 않아요.

- 설치 후속: 공개313d350을 C:/Users/kirby/HBEngine/Versions/132fdf6dbc8d09ed/HBEngine.exe로 갱신했어요.1,739파일/24개 소스·배포·설치 SHA를 확인했고 이전246버전/사용자42b실행27356/기본ADB14204/프로필을 보존했어요. 바탕화면 바로가기는 다음 실행부터 적용돼요. 증거native/build/streaming-audio-user-install-313d350.json. 새iOS37443947971은 같은313d350에서 진행 중이고 실물검증·현재원문게임검사 통과로 계산하지 않아요.

### 2026-10-06 — 검사 중복 축소와 현재 게임 결과

- 사용자의 비용 절감 요청으로 이전 패키지의 8시간 검사 zjUtGE/HjSnC6 및 선택적 짧은 진단 Koen3Q를 종료했어요. 중단 기록은 각 user-reduced-verification.json이며 8시간 완료/통과로 계산하지 않아요. 현재313d350 패키지의 69q8fO 한 개만 백그라운드에 남겨요. 시작 UTC09:56:21, 예정 종료 한국시간10월7일02:56:21. 반복 상태 조회나 이 검사를 기다리는 대화는 하지 않아요.
- 현재 원문 게임 검사는 checker-Sz6NWP에서 출력된 8개 검사/code0 통과예요. 앞서 말한 9개를 정정해요. 원본596파일·검사기41c24d19209bbc6aa7c826673de90b56b430113a3ca623832616b4ab9539a834·게임·사본 보존을 확인했어요. 원본 게임은 덮어쓰지 않았어요.
- 이전 게임 사본의 웨이브 실패는 대조 t39tPg에서 적 출현 대기 중 ClearRoom 호출 한 줄을 제거했을 때 처치3→6, 조기 완료6프레임→664프레임으로 달라졌어요. 격리 사본만 비교했으며 엔진/원본 게임은 수정하지 않았어요. 현재 원문에는 이 줄이 없고 위 검사도 통과해요.
- iOS37445272316/7e39704는 두 SDK 컴파일·설치·실행1080프레임/오류0까지 확인했지만 외부 Node의 앱 HTTP 요청이 시간 초과라 전체 실패로 보존해요. 실제 WKWebView는 WAV2초 재생·12개 측정 신호와 유휴 종료를 보고했어요. 에셋 SHA/Range/동시SVG/잘못된Range/네이티브소스 차단 검사를 실제 WKWebView 클라이언트로 옮기고 빠른 정상/손상 대조와 문법 검사를 한 번 통과했어요. 실제 수정 CI 결과는 아직 미검증이에요.
- Android 휴대폰이 없다는 사용자 답변을 기록해요. 실물 기기 발열·터치·30fps를 에뮬레이터 성공으로 대체하지 않아요. MD의 미체크3개는 그대로예요. 사용자 설치본132fdf6dbc8d09ed/313d350을 유지하며 이번 검사 도구 수정만으로 재설치하지 않아요.


### 2026-10-06 — A14·A15 C++ 보조 소스와 타일 묶음 구현

- A14: 프로젝트 Source/ 아래 h/hpp/hh/inl/cpp/cc/cxx를 상대 경로로 보존하고 편집기·화면 없는 실행·Windows·Android/iOS 출력에 함께 연결했어요. 보조 구현 변경도 캐시 키에 포함해요. 파일512개/개별500KB/전체8MB/기존60초 빌드 제한은 AI 스키마 build.nativeSources와 docs/PROJECT_NATIVE_SOURCES.md에서 확인할 수 있어요.
- A15: C++ Tilemaps::SetTiles / BP 여러 타일 지정·삭제(tileSetMany)를 추가했어요. 좌표·인덱스 배열을 명령 하나로 보내고 평균 O(N+M)로 처리해요. 중복은 마지막 값, -1은 삭제이며 잘못된 묶음은 전부 거절해요. 개별 SetTile의 기존 선형 비용은 남으므로 대량 생성에 묶음 함수를 사용해요.
- project-native-MthcAq: 실제 GCC의 하위 폴더/보조 구현·엔진 함수 연결·조건부 include·캐시 무효화·두 모바일 AOT 모듈의 이름/정적 상태 격리·실패 원자성 통과예요. 4,096칸 C++ 묶음8.2483ms, 두 명령 JS 적용2.2043ms예요. 단일 검사 구간이며 화면 FPS나 실물 기기 수치가 아니에요. 기존2D 확장과 공용 모바일 Player 검사도 통과했어요. 추가한 AI 소스 스키마와 API 생성 결과를 확인했어요.
- 현재 원문 데모 checker-Ejbhs1은 출력8개/code0 통과예요. 원본612파일과 검사기15d7d4fd5ff6432d3ce3e194eda15c9fe44c0d43ddb95213dd5c507ef3da6f7c, 사본 SHA ccc4670e0b2b0f898ad65275500cf50e4077dd286b07ff3ee90ade76648271d7을 보존했어요. 앞선 checker-kPaAr1의 보조 cpp 엔진 함수 링크 실패는 공통 컴파일 사본에서 Native.hpp를 포함하도록 고친 뒤 실패 검사만 다시 확인했어요. 원본 게임/검사기는 변경하지 않았어요.
- iOS d32c86a/run37447414087의 실제 아티팩트를 받아 두 SDK 컴파일·설치/실행·공유 C++/물리·실제 WKWebView SHA/Range/동시SVG·네이티브 소스 차단·오디오 신호·배경 정지/복귀 월드 보존 통과를 확인했어요. 이 결과는 새 A14/A15의 Xcode 검증이 아니며 실물·서명은 false예요.
- 구현을 사용자 설치본으로 갱신해요. 원본 게임·프로필·현재 사용자 창은 보존해요. 실물Android/실제8시간/PC와실물최종성능의 미체크3개는 유지해요. 현재 고정313 패키지69q8fO 한 개의8시간 검사는 백그라운드이며 반복 조회/중복 장시간 검사를 추가하지 않아요.


- A14/A15 설치 후속: 공개 한국어 커밋c9d3ac6193c6cdd7e20f7b68e228175737d1cd4a을 C:/Users/kirby/HBEngine/Versions/91e71ba94bdc11d9/HBEngine.exe로 갱신했어요. 1742파일과17개 소스·배포·설치 SHA를 확인했고 이전132f 버전/프로필/사용자 앱46636/기본ADB14204를 유지했어요. 바탕화면 바로가기는 다음 실행부터 새 버전이에요. 설치 증거 native/build/project-source-user-install-c9d3ac6.json. 새 A14/A15의 iOS 원격 검증을 한 번 요청했으며 결과 수집 전이에요. 설치 기록 스크립트의 문자열 줄바꿈 오류는 설치 전 파싱 단계에서 발생해 바로 수정했어요.


### 2026-10-06 — A14 호환 보강과 공용 2D 블렌드 스타일

- c9d3ac6의 iOS CI37453296535는 공용 headless 검사에서 구형 User.h include가 없어 실패했어요. 실제 Xcode 단계는 실행되지 않았으며 통과로 계산하지 않아요. 별도 Windows Player에서도 헤더 include 없이 저장된 보조 cpp가 실패해 두 기록을 보존했어요. 공통 소스 제작기가 User.h 호환 별칭과 같은 이름의 보조 헤더를 제공하고, 모바일 AOT의 프로젝트 include는 자기 모듈의 상대 경로로 고정해요. 실제 GCC project-native-yDfZkU와 headless가 최종 통과했어요(4소스·2AOT·4096칸 C++7.7379ms/JS1.2794ms; 화면 FPS 수치가 아니에요).
- Unity6000/URP17.0.4 공식 본문·API·고정 셰이더/스타일 소스를 대조해 Renderer2D의 공용4스타일, 곱셈·가산·감산, RGBA/반전 마스크를 씬·BP·C++6함수·AI에 연결했어요. 스프라이트 잘라내기/반전과 타일 갱신에도 같은 마스크를 사용해요. 화면 크기의 추가 렌더 타깃 없이 기존64광원 상한을 유지해요. 범위와 SHA는 docs/research/2D_BLEND_STYLES_033.md예요.
- CPU/C++/AI·기존2D 조명·렌더 수명 검사를 한 번 통과했고 실제 에디터 dILucz와 Player dzqYeh는 각각133개/조명83개·오류0이에요. 추가 타일 마스크/갱신 두 항목만 보강한 실제 GPU5o3l8N은135개/조명85개·오류0이에요. 이미 통과한 전체 게임·모바일·장시간 검사는 중복하지 않았어요. 원본 Auric 소스/에셋/검사기는 변경하지 않았어요.
- 수정분을 새 불변 사용자 설치에 반영하며 현재 실행 창·프로필·이전 버전을 보존해요. 실물Android/실제8시간/PC와실물최종성능 미체크3개와 고정313 패키지의 단일69q8fO 검사는 유지해요. 전체 엔진/전체 본문/API 완료로 이 결과를 올리지 않아요.

- 설치 후속: 공개 한국어 커밋 b93ad7f를 C:/Users/kirby/HBEngine/Versions/f39e8619a2936aff/HBEngine.exe로 갱신했어요.1745파일/27개 소스·배포·설치 SHA가 일치해요. 바탕화면 HBEngine 사용자용.lnk는 새 버전이며 다음 실행부터 적용돼요. 이전91e 버전·프로필·현재 사용자앱46636·기본ADB14204를 보존했어요. 증거 native/build/blend-source-user-install-b93ad7f.json. 같은 소스 iOS 검증은 한 번 요청했으며 결과는 별도 수집해요. 설치 후 누적 엔진 기능을 계속해요.


### 2026-10-06 — 프레임 MD 전체 반영·실행 비용 보강

- 별도 요청 문서 docs/엔진_요청_프레임.md의 본문·추가 회귀 대조·release 패키지 결과까지 읽었어요. 원래 42b의18.9/24.1ms, f39의26.8/46.5ms 기록을 보존해요. 자체 ABBA 대조에서 그 증가폭은 재현되지 않았고 사용자 측정을 오측정으로 처리하지 않았어요.
- PC120/fixed·Android/iOS60/display(15~240/설정 가능)를 편집기·Player·빌드 프로필·AI 스키마에 연결하고 물리1/60을 유지했어요. C++ 두 모듈 시계+사용자 호출을 한 프런트엔드 왕복으로 묶고 지속 WebSocket, 바뀐 C++ 행/필드와 변환만 동기화, 불변 UI 값 공유, 정적/잠든 물리 생략·연속 물리 쓰기 묶음을 적용했어요. 설치 루트 HBPlayer.exe 패키징 경로와 다른 BP의 같은 클래스 소스 충돌도 고쳤어요.
- 실제 Windows release Game.exe의 고정 Test_Valen 사본(실행432개) 대기3초118.67fps/작업중앙값6.70ms/p958.20ms, F9 전투·마우스 공격6초116.37fps/6.80ms/9.60ms예요. 물리·AI·애니메이션과 사용자 C++·렌더를 제외한 평균 엔진 비용3.669/3.957ms예요. 평균4ms 아래이며 모든 프레임4ms 상한/항상120fps를 확인한 결과가 아니에요. 실제 패키지 스프라이트 로드·한글 HUD 텍스트·오류0·HTTP native 호출0을 확인했어요.
- 실제 공용 C++/물리156항목/시계·호출 순서와 재전송 방지/프레임 계약·취소·예산 검사를 통과했어요. Android android-mobile-INkAIJ에서 Java/DEX/JNI/C++ 두 CPU·16KB 정렬·APK 서명·AAB·60/display·원본 보존을 확인했어요. 실제 휴대폰60fps는 기기가 없어 미검증이에요. iOS의 동일 소스 Xcode 결과와 설치 경로는 후속 기록에 남겨요.
- 상세 docs/research/FRAME_PERFORMANCE_20261006.md/JSON, 로컬 native/build/frame-regression-Y3u0Qb/package-performance.json. 원본 게임/검사기·프로필·열린 사용자 창을 바꾸지 않고 고정313의8시간 검사 한 개를 그대로 유지해요. 새로운 장시간 검사·통과한 전체 검사 반복은 추가하지 않아요. 전체 엔진/전체 문서 분석 완료로 계산하지 않아요.

- 설치 후속: 공개 한국어 커밋7ff2a0775c5192fbd13d48296ae9f88b5ae70718을 C:\Users\kirby\HBEngine\Versions\f174d1db6a5da180\HBEngine.exe로 갱신했어요. 1773파일/실행·전송·프레임·API·문서 48개 SHA가 소스/배포/설치에서 일치해요. 바탕화면 HBEngine 사용자용.lnk는 새 버전이며 다음 실행부터 적용돼요. 기존 f39 버전·사용자 앱43288·기본ADB14204·사용자 프로필을 보존했어요. 설치 증거 native/build/frame-user-install-7ff2a07.json. 현재7ff의 iOS 원격 run37465181522는 요청 한 번/결과 대기이며 기존 b93의 동일 클래스 Xcode 충돌 실패를 새 통과로 덮지 않아요.

- 설치본 최종 검사: frame-installed-CS46bD에서 원문 tools/check_demo.mjs를 고유 사본으로 한 번 실행해 출력8개/code0 통과했어요. 원본613파일·검사기 SHA 15b4183135a6d0ee07ca38c313058d4ec9857442f2fa720cb4f275b0efa7b4a0·사본이 보존됐고 동시 원본 변경0개예요. 새 설치본의 실제 tools/build-game.mjs로 release Game.exe/762파일/C++2모듈/120·fixed 제작도 통과했어요. Game.exe와 설치 루트 HBPlayer.exe SHA가 일치해요. 기존 dist/HBEngine 경로 오류가 해결됐어요. 증거 native/build/frame-installed-acceptance.json. 이 마지막 검사는 장시간 반복하지 않았고 사용자 창을 실행/종료하지 않았어요.

- iOS7ff/run37465181522의 실제 clang 로그는 공용 C++/A14 같은 클래스 두 구현·시계 묶음·전송·headless·오디오까지 통과했어요. Player 종료 검사에서 새 frameLoop를 테스트 더블에 제공하지 않아 failureCleanup이 생기기 전에 실패했고 Xcode는 건너뛰었어요. 검사 더블을 현재 함수에 맞추고 실제 프레임 정지/모바일 정지·재개/예약 조건을 확인했어요. 도구 수정뿐이며 설치된 실행 코드에는 변경이 없어요. CI 재검사는 기준 SHA와 현재 실행 소스가 같을 때만 이미 통과한 공용 항목을 재사용하고 남은 검사·모바일 프로젝트 출력·Xcode·시뮬레이터를 진행해요. 기본 CI는 전체 검사예요.

- 최종 사용자 버전은 C:\Users\kirby\HBEngine\Versions\82abc860ad41c075\HBEngine.exe예요(290c538,1,773파일/49개 SHA). Player 수명 검사 도구와 설치·데모·패키징 기록도 포함했어요. 실행 코드·프레임 성능은 7ff와 동일하고 두 번의 배포는 각각 별도 불변 폴더예요. 열린 사용자43288·ADB14204·이전 f174/f39·프로필을 유지했으며 바로가기는 최종82abc860ad41c075를 가리켜요. 증거 native/build/frame-user-install-290c538.json. 이후8bfe946은 원격 부분검사 폴더 준비 한 줄만 바뀌어 앱 재설치는 하지 않아요. 290의 iOS 공용 수명/프레임/채널/에셋 검사는 통과했지만 새 작업 폴더 누락으로 다음 검사에서 실패했고 이를 고쳐 다시 진행해요. 이 실패나 이전 Xcode 건너뜀을 통과로 표시하지 않아요.

- 마지막 상태: 최종 설치82abc860ad41c075의 실행 파일39개는 실제 성능을 잰7ff 버전과 SHA가 같아요. 새 설치본 원문 데모8개·원본613파일/검사기 보존·실제 설치 도구 release 패키징·Android APK/AAB는 완료예요. 동일 실행 소스의 iOS run37466333179(8bfe946)은 남은 공용 검사/모바일 프로젝트 출력을 통과하고 Xcode·시뮬레이터 단계에서 진행 중이에요. 결과 링크 https://github.com/kirby47navercom-ai/HBEngine/actions/runs/37466333179. 아직 성공으로 계산하지 않아요. PC와 모바일 목표값은 반영됐지만 PC 항상120fps/각 프레임 고정비용4ms 상한/휴대폰60fps 실측을 완료로 표시하지 않아요. 기존8시간 검사69q8fO 한 개는 유지하며 새 장시간 검사나 사용자 창 재실행은 추가하지 않았어요.

### 2026-10-06 — iOS 동일 실행 소스 통과·추가2D 제작 광원

- iOS400d696/run37468368819의 SDK18.5 device/simulator 컴파일과 독립 iPhoneSE3 실행600frames/errors0, 두 동일클래스 C++/Rapier 질의·배치 위치/한글·SVG/WAV ranges/오디오12신호·재사용·백그라운드복귀를 확인했어요. actual phone/signing/heard는 false예요. 이전 초기launch timeout과 검사 수정 근거는 IOS_STARTUP_20261006.md에 보존했어요.
- Unity 공식 Light2D 본문/API/고정 셰이더 근거로2D Sprite cookie/볼륨·독립 그림자를 Scene/BP/C++7/AI·출력에 연결했어요. CPU/C++ 검증과 실제Windows Player wd42dX160개/조명110개/errors0, 모바일공용 uav3wz C++/출력이 통과했어요. 새광원은 앞 iOS 성공에 포함하지 않고 해당 소스에서 한 번 따로 확인해요. 원본 게임/검사기/사용자 창 변경은 없어요.


### 2026-10-06 — iOS 실행 통과와 추가2D 광원 사용자 업데이트

- iOS400d696/run37468368819은 Xcode18.5 기기·시뮬레이터 컴파일 뒤 실제앱600프레임/오류0, 동일클래스 C++두모듈/동기Rapier/배치위치 보존·한글/SVG/WAV range·오디오12신호·버퍼재사용·백그라운드정지/복귀를 통과했어요. 원래launch timeout과 준비순서 검사 수정은 docs/research/IOS_STARTUP_20261006.md에 남겼어요. 실제휴대폰/배포서명/소리를귀로듣기는 미검증이에요.
- 공식본문/API/고정셰이더를 토대로2D Sprite Light cookie(RGBA/crop/PPU/pivot)·볼륨 빛/독립 그림자를 Scene·BP·C++7개·AI·PC/모바일 에셋출력에 연결했어요. 사용된64×최대256²배열 공유/정적업로드0/볼륨당1평면·추가전체화면타깃0을 유지해요. CPU/C++/의존성과 실제Windows Player160개/조명110개·오류0, 모바일공용 C++/프로젝트출력을 통과했어요. 세부범위는 docs/research/2D_COOKIE_VOLUME_035.md예요.
- 공개 한국어 커밋950f4a9cd7015fad4e01785f1c2dea7ce2ac2f92를 C:/Users/kirby/HBEngine/Versions/87b7af9ce10a2ee9/HBEngine.exe로 갱신했어요.1777파일/소스·배포·설치30SHA 일치, 바로가기는 새버전이며 다음실행부터 적용돼요. 현재사용자창43288·기본ADB14204·이전82abc·프로필과 원본게임/에셋/checker를 보존했어요. 증거 native/build/light-cookie-user-install-950f4a9.json. 새광원의 iOS 검사는 run37471088488에서 진행해요(앞600프레임 성공에 새광원을 포함하지 않아요).
- 앞 프레임요구 PC120/mobile60 설정과 고정사본118.67/116.37FPS, 평균고정엔진비용3.67/3.96ms 기록은 유지해요. 광원추가만으로 항상120/실물60/전프레임4ms를 주장하거나 검사표의 실물·8시간 완료칸을 올리지 않았어요. 사용자요청대로 새장시간검사·이미통과한게임검사 반복은 추가하지 않았어요.

### 2026-10-06 — 파티클 공용2D 렌더러와 모바일 기본레이어 결함 수정

- ParticleSystem에 레이어/순서·Sprite Mask none/inside/outside를 Scene/BP·C++ Components·AI 공용 속성으로 연결했어요. ShaderMaterial mask hook·SortingGroup·타깃 해제와 3D 기본 깊이정렬을 유지해요. 입자별 임시 벡터/배열과 역행렬·viewport 할당을 재사용해요. 실제Windows Player wlEr8c170개/조명111개/errors0과 실제C++·CPU 버퍼/좌표/보간/UI 순서 검사가 통과했어요.
- fed46d4 iOS37472250751은 두SDK·설치·launch를 통과했지만 선택필드 sortingLayers 누락을 volume 코드가 허용하지 않아 앱0프레임에서 실패했어요. 공용Renderer에 기존기본레이어를 먼저 적용하고 같은 누락조건의 RGBA 동일 회귀를 통과했어요. 모바일공용 uT5pYZ C++2AOT/새광원·particle-mask 포함 출력도 통과했어요. 실제새iOS 결과는 후속 기록하며 앞실패를 성공으로 덮지 않아요.
- CI는950f와 같은C++/native/API/VM/서비스/전송 기반에 한해 재사용하고 Renderer/metadata 변경은 runtime-feature·scene-system·particle-renderer와 기존6개·SDK/실제앱을 검사해요. 범위 밖 변경은 전체검사를 요구해요. 사용자원본/창은 변경하지 않았고 새8시간이나 원문게임검사는 추가하지 않았어요.


### 2026-10-06 — 기본2D 레이어·파티클 렌더러 수정 사용자 설치

- 공용2D Renderer에서 선택필드 sortingLayers가 없는 기본·구형 장면에 기존Default를 적용해 volume 실행중단을 고쳤어요. ParticleSystem의 정렬레이어/순서·Sprite Mask none/inside/outside·SortingGroup과 ShaderMaterial을 같은 렌더러에 연결했고, 기본3D perspective 파티클의 투명오브젝트 깊이정렬은 유지해요. Scene/BP/C++ Components/AI가 같은 속성을 다뤄요. 입자별 임시벡터/배열과 역행렬·viewport 할당도 재사용해요.
- 최종 실제Windows Player wlEr8c170항목/조명111항목·오류0, 실제C++/버퍼world-local/색보간·원본보존·UI필드순서, 모바일공용 uT5pYZ의 C++2AOT/새광원·particle-mask 포함 출력이 통과했어요. 공식본문/API/Niagara Sprite 세부대조와 남은renderer항목은 docs/research/PARTICLE_RENDERER_036.md에 적었어요.
- 공개 한국어 커밋76c2bf31bdc2d8424b49af050ef0e2e932628526을 C:/Users/kirby/HBEngine/Versions/a84724c3bafa35be/HBEngine.exe로 갱신했어요.1779파일/소스·배포·설치34SHA 일치, 바로가기는 새버전이며 다음실행부터 적용돼요. 이번 갱신 당시 사용자창34080(82abc버전)·기본ADB14204·이전버전·프로필을 보존했어요. 증거 native/build/particle-layer-user-install-76c2bf3.json. 원본게임/에셋/checker는 변경하지 않았어요.
- fed46d4 iOS37472250751은 두SDK/install/launch 성공 뒤 위optional-layer 결함으로0프레임에서 실패했어요. 로그/보고를 보존했고 새소스의 run37474343475는 변경영역/공용기반 검사와 프로젝트출력을 통과한 뒤 실제SDK/앱 검사를 진행해요. 성공으로 미리표시하지 않아요. 같은C++기반의 이미통과한검사 묶음은 재사용하고 새장시간/원문게임 반복검사는 추가하지 않았어요. 실물폰/서명/가청/기존8시간 완료칸은 유지해요.


### 2026-10-06 — iOS 새2D 광원·파티클 실행 확인

- source76c2bf3의 실제 원격iOS run37474343475가 두SDK/독립iPhone SE3/실제WKWebView 실행/C++2AOT/동기물리/파일SHA·range·병렬SVG/오디오 신호·일시정지·복귀를 통과했어요. 오류0/보고960frames, Cookie65536bytes·볼륨visible/order8·9셰이더runnable/실제Points5개를 확인했어요. 파티클mask GPU 픽셀 비교는 Windows 증거이고 이번iOS 진단은 실제 생성/그리기와 셰이더링크 범위예요. 설치a84724c3bafa35be와 같은 실행소스예요.
- 성능창600frames는17.8269fps/work p50 39/p95 53ms로 모바일60 목표미달이에요. 기능PASS를 성능PASS로 바꾸지 않고 실물폰/서명/가청/8시간 확인칸을 그대로 둬요. iOS 요약 native/build/ios-76c2bf3-summary.json·원본zip/화면을 보존했어요. 이후 개별 입자 정렬·화면크기·적분 재사용 수정은 이source에 포함하지 않아요.


### 2026-10-06 — 파티클 개별 정렬·화면 크기·실행 설정 연결

- Renderer의 입자별7정렬/직교거리=깊이/카메라별 즉시업로드·none복귀/화면 최소·최대·0숨김, Scene/BP/AI와 C++기존Components6Set/Get을 연결했어요. 실제Windows M637rV181/조명111/errors0·CPU버퍼/C++/입자 원본 보존을 확인했어요.
- 적분 임시배열·사망 filter를 제자리재사용으로 바꾸고 이전공유소스640step 동일결과(1e-8)를 확인했어요. 짧은10000입자20step×3 CPU중앙값2.326575→.117655ms/step이며 게임FPS/실물폰/8시간 증거가 아니에요.
- 실제VM으로 기존시스템의 rate/speed 변경이 실행에 안반영됨(기대4/실제0)을 발견해 공용설정 연결을 고쳤어요. 방출4/speed6와 Pause/clear·C++/런타임 회귀가 통과했어요. 정렬·크기·서비스수정은 앞iOS76c 결과에 포함하지 않으며 새source전체공용/SDK/app으로 확인해요. 원본게임/checker/사용자창을 바꾸지 않았어요.


### 2026-10-06 — 파티클 실행 보강·프로젝트 파일 연결 사용자 갱신

- 실제Windows Player M637rV181항목/조명111/오류0으로 입자별7정렬·직교거리·두카메라 즉시업로드·화면 최소/최대/0숨김과 기존Mask/SortingGroup/3D깊이/광원/C++를 확인했어요. C++기존Components6Set/Get·Scene/BP/AI·640step 이전소스 비교·Pause/Reset·원자성·실제VM의 살아있는 rate/speed 갱신도 통과했어요. 적분 CPU10000입자20step×3 중앙2.326575→.117655ms/step은 게임FPS/실물폰 증거와 구분해요.
- 공개 한국어 커밋6537f3b의 파티클/서비스 보강과 Windows 전용fac7946의 파일 연결을 C:/Users/kirby/HBEngine/Versions/c611c381db853f76/HBEngine.exe로 갱신했어요.1780파일/소스·배포·설치20SHA 일치, 바로가기와 실제HKCU .hbproject open command 모두 같은 새버전이에요. 등록은 기존 --register를 hidden/분리임시프로필로 실행하고 개발폴더 일반실행의 자동등록을 제외해요. 설치기 검사 동안 현재사용자PID2688(82abc)/기본ADB14204·이전a847/23f버전을 보존했어요. 사용자창을 재시작하지 않았고 다음실행에 적용돼요. 증거 native/build/particle-association-user-install-fac7946.json.
- 첫6537 설치는 복사/링크 뒤 PID동일성 guard가 실패했고 실패로그를 보존해요. 검사 전후 세션PID가 달랐으며 어느 사용자동작이 있었는지 확인하지 않았어요. 이시도를 PID보존PASS로 바꾸지 않아요. 설치기 코드에는 기존프로세스 종료/재시작이 없으며 최종설치에서는 전후PID/생성시각/경로 보존을 실제확인했어요.
- iOS의 실제새파티클/서비스 source6537 run37476970087은 전체공용C++/기반 검사와 모바일출력을 통과한 뒤 SDK/앱 단계예요. Windows전용후속fac는 모바일 실행소스를 바꾸지 않아요. 앞76c의 실제광원/Points/9shader·C++/물리/오디오/복귀 통과는 별도source이며600frames17.8269fps/p95 53ms로60목표미달을 그대로 기록해요. 새run 성공을 미리표시하지 않고 실물폰/서명/가청/기존8시간 칸도 그대로 둬요. 원본게임/에셋/checker는 바꾸지 않았어요.


### 2026-10-06 — 파티클 새 소스 모바일 결과 확인

- source6537f3b의 iOS run37476970087 전체 공용 C++/기반·모바일 출력·Xcode 기기/시뮬레이터 SDK·독립 iPhone SE3 앱600프레임/오류0을 통과했어요. 새 depth/min.015/max.2/mask 설정을 포함하며 cookie/volume·9셰이더 runnable·Points5·C++2AOT/동기물리/한글·SVG·오디오 신호/정지·복귀를 확인했어요. GPU 입자 정렬·mask 픽셀 비교는 Windows181항목 증거이며 iOS에서 같은 픽셀 비교까지 완료했다는 뜻은 아니에요. 실제 폰/배포서명/가청은 미검증이에요. https://github.com/kirby47navercom-ai/HBEngine/actions/runs/37476970087
- iOS599 측정프레임은15.4191fps, work 중앙43/p95 73ms, simulation 평균45.3489/p95 72ms, render 제출 평균.9332/p95 2ms예요. 모바일60 목표미달을 유지해요. 앞76c 시뮬레이터 결과와 실행부하가 통제된 쌍 비교가 아니므로 파티클 수정의 회귀/개선으로 단정하지 않아요. 순수 CPU 입자 적분 개선은 게임 전체 FPS와 구분해요.
- Android android-mobile-NfoYil에서 새 실행소스의 APK/AAB 각각 arm64-v8a+x86_64 Java/DEX/JNI/C++·16KB ELF/패키지·서명·원본 보존을 통과했어요. APK SHA8c15b41635fd6e3568decf5906fa47767f34a107805a0bbd4849748584fd3573, AAB SHA622e05964d826b6adcffec38bde5606329bdebceb9dac396cfb7566b702ee6d0이며 실제 네 공유실행파일 SHA도 각 패키지와 같아요. 기기설치/실행은 하지 않았어요. 증거 native/build/particle-mobile-037-summary.json.
- 최종 사용자 설치본은 fac7946/c611c381db853f76이고 후속 기록 커밋을 설치 실행코드로 바꾸지 않아요. 사용자 창/원본게임·검사기·프로필/기존8시간 검사는 건드리지 않았고 새 에뮬레이터·장시간 검사·통과한 광범위 반복검사를 추가하지 않았어요.

### 2026-10-07 — iOS 직접 응답·게임 오디오 시작과 Android 새 패키지

- 실행 source bb36739, iOS run37485278400은 Xcode 기기·시뮬레이터 SDK/독립 iPhone SE3 앱480프레임·오류0을 통과했어요. WebKit Promise 직접 응답·callAsyncJavaScript 동기 Rapier 질의·C++2모듈/배치 위치 보존·잘못된 호스트 메시지8종/알 수 없는 질의 거절, Sprite Light cookie/볼륨·셰이더·한글/SVG·WAV2초 길이/최소4초 믹서 신호·배경 정지/복귀·BeginPlay 재실행0을 실제 앱에서 확인했어요. 실제 휴대폰/서명/가청 검증과는 구분해요. https://github.com/kirby47navercom-ai/HBEngine/actions/runs/37485278400
- 이전 새 브리지 앱의 audio idle/queued1 실패를 보존하고, native 모바일 Player가 명시적으로 unlockAudio를 시작하도록 고쳤어요. 응답 스크립트의 우연한 사용자 활성화에 의존하지 않으며 OS resume Promise를 기다려 게임 시작을 막지 않아요. PC/브라우저 입력 방식은 그대로예요. check-player-lifecycle·check-mobile-bridge 및 실제 앱의 기존 오디오 합격 조건을 통과했어요. 실패3회는 성공으로 바꾸지 않았어요.
- iOS479측정 프레임 work 평균46.8977/중앙41/p95 77ms, simulation 평균45.7850/p95 75ms, 렌더 제출 평균.9791/p95 2ms이며60목표미달이에요. 보고 FPS14.3572는 배경 복귀가 포함된 이 검사 구간 값이며 전/후 CI의 실행부하가 통제되지 않아 브리지 개선률이나 회귀로 단정하지 않아요. 실제폰60을 확인한 결과도 아니에요.
- Android android-mobile-bQ34Wa에서 새 Player/bridge 소스 SHA가 APK·AAB에 실제 포함됨을 확인했어요. 두 CPU Java/DEX/JNI/C++·16KB ELF·정렬/서명·AAB/게임 원본 보존 통과, 기기설치/실행 없음이에요. APK SHAeb3bd0786171163111c957ce8bcec2f23a460d67503637492578717251b3ef07, AAB SHA6c6f401f1b8f8e29225385b11b5073a086bf37172d8bf5c26dadf0f4086caded예요. 기존 검증의 격리 게임을 재사용해 공용 C++ 검사를 반복하지 않았어요.
- 증거 native/build/ios-bridge-result-038.json·ios-bridge-37485278400-ios-acceptance.json·ios-bridge-android-038.json. 사용자 창/원본 게임·에셋·C++·검사기·프로필·기존 장시간 검사는 건드리지 않았어요. 전체 엔진/전체 문서 완료로 바꾸지 않아요.

- 2026-10-07 사용자 설치 완료: source ad5ca6f(실행 bb36739)/bundle5946523bdd1003b6, C:/Users/kirby/HBEngine/Versions/5946523bdd1003b6/HBEngine.exe. 1783파일/변경 실행·검사·문서15개 SHA 일치, 기존 c611 설치 manifest/프로필과 당시 adb14204 보존, 바탕화면 사용자용 바로가기 및 HKCU .hbproject 실행 경로 일치예요. 설치기에서 사용 중인 앱을 열거나 닫지 않았어요. 설치 전 기존 HBEngine 프로세스는 없었으며 다음 실행부터 새 버전이에요. 증거 native/build/ios-bridge-user-install-038.json. 이 뒤의 기록 커밋을 설치 실행 소스로 혼동하지 않아요.


### 2026-10-07 — 실제 앱의 파티클 출력·활성 시간 측정 확인

- 실행 source478e610, iOS run37487615079은 기기/시뮬레이터 SDK 컴파일·독립 iPhone SE3 WKWebView 앱1080프레임/오류0을 통과했어요. production 파티클의 흰색·선형 RGB/alpha·두 tone mapping·화면/선형/sRGB 타깃12조합, 비대칭 UV2개·셰이더 링크1개 총15조건이 기본 PointsMaterial과 일치했어요. 기존 C++2AOT/동기Rapier/파일 range·한글/SVG·오디오 신호·배경 정지/복귀도 통과했어요. https://github.com/kirby47navercom-ai/HBEngine/actions/runs/37487615079
- 실제 Windows Hh3b8Y에서도 기존2D181/광원111와 새15조건·오류0이에요. Android Lwbr7o 두CPU Java/DEX/JNI/C++·16KB ELF/서명·정렬·APK/AAB와 실제 패키지의 공유 실행파일4개 SHA 일치를 확인했어요. APK SHA7c560f279ae2fac358fad244e88734b15532bb8f3f1deed7c7696b44dfa9fc70, AAB SHA7f45fb5bced8eb48cde92579b23f8a843d12e34635ecd2bab5c396633cc1dbb7예요. 실물폰 설치/실행·iOS 배포서명·가청은 미검증이에요.
- FrameProfiler가 배경6초를 interval/work/simulation에 섞던 문제를 공통 활성 시계로 고쳤어요. 표본을 삭제하거나 큰 값을 제한하지 않아요. 실제 iOS 마지막600프레임25.2951fps/work 평균39.2833/중앙37/p95 58ms, simulation 평균38.1167/p95 57ms, render 제출 평균1.0383/p95 2ms이며60목표미달이에요. 앞 CI와 부하가 통제된 비교가 아니며 측정 정정을 성능 개선으로 주장하지 않아요.
- check-frame-rate·check-player-lifecycle의 실제 함수 회귀, 변경 Renderer/VM 검사를 통과했고 불변 C++ 공유 기반은 소스 대조로 재사용했어요. 증거 native/build/particle-color-result-039.json·ios-color-37487615079-ios-particle-color.json·particle-color-android-039.json. 새 장시간 검사를 추가하거나 원본 게임/에셋/C++/검사기·사용자 창·프로필·기존8시간 검사에는 손대지 않았어요.
- 엔진_요청_프레임.md의 새 보스전 기록(기존 설치82abc,78.2fps·simulation 평균10ms·편집기 clientOperations 약160ms/0.3초)을 확인했어요. 이 기록을 누락하지 않고 편집기 명령 적용 경로를 다음 조사 대상으로 유지해요. 전체 엔진/전체 API 완료로 계산하지 않아요.

- 2026-10-07 사용자 설치 완료: source273f38a(실행478e610)/bundleff86c664879f12a3, C:/Users/kirby/HBEngine/Versions/ff86c664879f12a3/HBEngine.exe.1785파일/변경21SHA 일치, 기존5946523 설치 manifest·프로필과 adb14204 보존, 사용자용 바탕화면 바로가기/HKCU .hbproject 경로 일치예요. 설치 당시 실행 중인 사용자 엔진은 없었으며 앱을 열거나 닫지 않았어요. 다음 실행부터 적용돼요. 증거 native/build/particle-color-user-install-039.json. 이 뒤 기록 커밋은 설치 실행 소스와 구분해요.


### 2026-10-07 — Test_Boss 편집기 에셋 이름 조회 비용 수정

- 새 MD 보고(보스78.2fps·편집기 약160ms)를 확인한 뒤 숨겨진773파일 사본으로 재현했어요. 새 애니메이션 이름을 찾을 때 전체 디렉터리를 다시 읽던 경로에서 명령 적용 최대399.8ms/playAnimation398.4ms가 나왔어요. Play 준비 목록을 Spawn catalog와 모든 실행 에셋 이름 조회가 함께 쓰도록 고쳤어요.
- 같은 사본 수정 후 명령 적용 최대8.4ms·평균.3ms/playAnimation 최대7.2ms·실행 중 폴더 재조회0회, 영구 --boss-only 실제 C++/300프레임 검사도 조회0/오류0·명령 최대3ms로 통과했어요. 순차 짧은 측정이며 항상120/실물60/전체 시뮬레이션 개선으로 단정하지 않아요. 불변 모바일/패키지 코드는 다시 빌드하지 않았어요.
- 원본 C++ TopDownShooter.cpp의 외부 변경은 보존했고 한 번 동결한 사본으로 이전/이후를 비교했어요. 원본773파일 모두 불변이라고 잘못 표시하지 않으며 원본·검사기·사용자창·프로필을 수정하거나 복원하지 않았어요. 세부 근거/본문 범위/증거 docs/research/EDITOR_PLAY_ASSET_LOOKUP_040.md·native/build/boss-asset-result-040.json예요. AI 여러문서/ C++ 묶음 수정·저장 준비도 유지하며 아직 구현 완료로 계산하지 않아요.

- 2026-10-07 사용자 설치 완료: sourcec150496/bundled03c655dc25a2bb6, C:/Users/kirby/HBEngine/Versions/d03c655dc25a2bb6/HBEngine.exe.1786파일/변경24SHA와 실제 회귀 창의 app.js가 일치하며 모바일·패키지·네이티브 실행소스는478e610 검증본 그대로예요. 기존ff86 설치 manifest/프로필·adb14204 및 사용자 창을 보존했고 바로가기/HKCU 프로젝트 실행 경로를 갱신했어요. 다음 실행부터 적용돼요. 증거 native/build/boss-asset-user-install-040.json.


### 2026-10-07 — 오브젝트 개수 제한 제거(042)

- 500→1,000처럼 대체하지 않았어요. 편집기/장면·프리팹 저장/프레임워크의500, Spawn·C++ 월드·모듈·물리 스냅숏의2,000, SaveGame의1,000/변수소유자500, 직접풀500, C++템플릿128/합산10,000 개수 제한을 제거했어요. ID·타입·변환·경로와 통신 크기 검증은 유지해요.
- 실제11검사: 1만 장면 저장/재로드·복사/삭제·프레임워크, 1,200계층 검색, BP/컴파일C++생성 후10,002월드, 10,001풀·Save/Load, 2,001변수 소유자/프리팹 및 잘못된 값 거절. 증거 native/build/object-capacity-KF4Vxz/acceptance.json·docs/research/OBJECT_COUNT_LIMITS_042.md. 1만은 새 제한이나120fps 성능 합격이 아니에요. 원본게임/창/프로필을 건드리지 않았어요.
- 하던 AI 다중 에셋/C++ 묶음 저장 작업(041)은 계속해요. 이 기록으로 누적 전체 작업을 완료 처리하지 않아요.


- 2026-10-07 사용자 설치 갱신(042): source0c9364f/bundlea2be41b1ab947dfb, C:\Users\kirby\HBEngine\Versions\a2be41b1ab947dfb\HBEngine.exe. 1788파일과18개 변경 SHA가 일치해요. 이전d03c655dc25a2bb6 설치를 보존했고 사용자창/프로필을 건드리지 않았어요. 바로가기·HKCU 프로젝트 연결이 새경로와 일치해요. 다음 실행부터 오브젝트 개수 제한 제거가 적용돼요. 증거 native/build/object-capacity-user-install-042.json. 미완료041 묶음 저장 코드는 이 설치본에 포함하지 않았어요. 모바일 새 APK/AAB·실기기 검증으로 계산하지 않아요.


### 2026-10-07 — AI 에셋·C++ 묶음 저장/Undo(041)

- files.get/apply/undo/redo, 디스크/열린 문서 revision, 동시 BP·부모·C++ 공개 시그니처 dryRun, 함께 저장하는 기록·중간 실패/재시작 복구와 전체 Undo/Redo를 연결했어요. C++만 수정해도 기존 작업창 Undo로 되돌려요. 새 인간 편집이 대기 중 생기면 보존하고 파일 묶음 전체를 이전 상태로 돌려 요청을 거절해요. 외부 변경은 덮어쓰지 않아요.
- 실제 파일/편집기 함수17검사(asset-transaction-Vj5W1F), 실제 숨겨진 Windows 엔진 창7검사(asset-batch-editor-5xq79Y): UI와 그룹 Undo/Redo·source-only Undo·실제 C++ 재컴파일/Begin Play X7→13·오류0 확인. changed production5SHA가 창 사본과 같아요. check-project/check-assets 통과. 원본게임/사용자창 불변이고 코드변경 없는 모바일/플레이어 빌드를 반복하지 않았어요.
- Unity 메서드 본문3개/Unreal FScopedTransaction 자체 클래스 본문을 근거로 import batching/오브젝트 Undo/파일 복구를 구별했어요. docs/research/AI_ASSET_TRANSACTIONS_041.md에 바이트64파일/8MB·세션Undo40/재시작/외부 충돌·실제 검증 범위를 적었어요. 전체 문서·전체 엔진 완료로 합산하지 않아요. 오브젝트 개수 제한 제거042는 유지해요.


- 2026-10-07 사용자 설치 갱신(041+042): sourcef424d4a/bundleb9a10dd421646ed4, C:\Users\kirby\HBEngine\Versions\b9a10dd421646ed4\HBEngine.exe. 1792파일/14변경SHA와 실제 창 production5SHA가 일치해요. 오브젝트 임의 개수 제한 제거를 유지하고 AI 묶음 저장·전체 Undo/Redo를 포함해요. 기존a2be 설치/사용자프로필·창을 보존했고 바로가기/HKCU 프로젝트 연결이 새경로와 같아요. 다음 실행부터 적용돼요. 증거 native/build/asset-batch-user-install-041.json. 전체 엔진/전체 조사 완료를 뜻하지 않아요.


### 2026-10-07 — 물리 개수 제한·전체 질의 결과 누락 제거(043)

- 042 후속으로 공유 물리 월드의 차원별 충돌체8,000/관절512, C++ snapshot 전체·타일 충돌체8,000 검사를 제거했어요. RaycastAll/Overlap의1,000개 절단도 제거해요. 단일 Raycast는 첫 결과만 변환하고 C++ snapshot 복사는 인자 펼치기 없이 반복해요. ID/형상/좌표/필터/통신 크기 검증을 유지해요.
- 수정 전 실제 1,201개 교차가1,000개로 줄어드는 실패를 재현했어요. 최종 tools/check-physics-capacity.mjs 10검사(physics-capacity-BRW5lX): 2D/3D 각각10,001충돌체/solver1프레임/전체겹침, 각각600관절, 한 오브젝트8,001타일충돌체, 실제 C++ RaycastAll/OverlapBox 각1,201결과·잘못된 값 거절. 기존 check-physics.mjs 156WASM검사와 C++/BP 연결도 통과해요. 검사 개수를 새 상한/FPS 성능 판정으로 쓰지 않아요.
- Unity6000.0 RaycastAll/OverlapBoxAll 자체 본문과 반환·정렬·메모리 의미를 읽었어요. docs/research/PHYSICS_COUNT_LIMITS_043.md에 근거/범위/최종2파일SHA를 기록해요. C++ 호출당128질의/4MB패킷·형상 크기 등 자원/입력 검증은 남아 있어요. 원본게임/사용자창·프로필/장기 검사를 건드리지 않았어요. 041/042 결과를 유지하며 이번 기록은 전체 엔진/조사 완료를 뜻하지 않아요.


- 2026-10-07 사용자 설치 갱신(043/041/042 유지): sourceec694c1/bundle533b2b30a45cf205, C:\Users\kirby\HBEngine\Versions\533b2b30a45cf205\HBEngine.exe. 1794파일/9변경SHA와 최종 물리검사2productionSHA가 일치해요. 이전b9a10dd421646ed4 설치와 사용자창·프로필을 보존했고 바로가기/HKCU 프로젝트 연결이 새경로와 같아요. 다음 실행부터 적용돼요. 증거 native/build/physics-capacity-user-install-043.json. 새 창/장기 검사를 반복하거나 새 모바일 패키지를 빌드하지 않았어요.


### 2026-10-07 — 큰 월드의 C++ 질의 준비 비용 제거(044)

- 공유 engineQuery가 각 snapshot행마다 전체 월드를 찾는 중첩 검색을 하던 원인이에요. 기존 bridgeStateIndices로 바로 찾고 범위/ID가 맞지 않으면 안전하게 기존 검색을 해요. 현재 actor transform/nativeProperties, 월드 순서와 추가 속성·검증을 유지해요. 새 캐시/의존성이나 개수 상한을 만들지 않았어요.
- 같은5,000행 실제 컴파일 C++ 입력의 snapshot/merge/패킷 구성 단계만 순차 비교했어요. 이전1,949.3/2,001.2/2,021.3ms → 이후31.2/33.4/34.6ms. IPC·물리·렌더링·전체FPS를 포함하지 않으며 장면 전체120fps 합격으로 쓰지 않아요. 원본게임/사용자창·프로필·장기 검사 불변이에요.
- query-world-ZgeKee에서 현재 transform/추가 값/행 순서와 잘못되거나 없는 인덱스 fallback을 실제 C++로 통과했어요. 새 SDK로 물리 capacity10검사(12CXiy), 기존156물리검사와 C++/BP연결, 실제 별도 C++ worker/Windows에서 만든 모바일 AOT 모듈 호출(RzTUIe), Spawn/Destroy/Construction/실패회복9검사(MXspEq)도 통과했어요. Android/iOS 실기기·새 패키지 검사가 아니에요. docs/research/CPP_QUERY_WORLD_LOOKUP_044.md·native/build/query-world-result-044.json에 근거를 기록해요. 041/042/043을 유지해요.


- 2026-10-07 사용자 설치 갱신(044/041/042/043 유지): sourcee8c34ae/bundle51cf0713e445a496, C:\Users\kirby\HBEngine\Versions\51cf0713e445a496\HBEngine.exe. 1796파일/8변경SHA·최종SDK SHA와 물리production2SHA가 일치해요. 기존533b2b30a45cf205 설치/사용자창·프로필을 보존했고 바로가기/HKCU 연결이 새경로와 같아요. 다음 실행부터 C++ 질의 인덱스 개선과 개수 제한 제거/AI 묶음 저장이 적용돼요. SDK 변경은 기존 빌드해시의 입력이므로 새 사용자 C++ 빌드에 반영돼요. 증거 native/build/query-world-user-install-044.json. 사용자 게임/기존 수출본은 덮어쓰지 않았고 새 모바일 패키지/실기기 검사는 실행하지 않았어요.
