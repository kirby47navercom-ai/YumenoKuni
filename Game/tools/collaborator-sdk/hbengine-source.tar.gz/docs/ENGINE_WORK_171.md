# 171 — 네트워크·코드 재적용과 제작 세부 확장

2026-10-16, 기준 `2e870ac`. [누적 원장](ENGINE_STATUS.md)의 미구현·잔여를 실제 편집·실행 경로로 이어간다. [검사 근거](research/ENGINE_WORK_171.json), 사용자 설치 확인은 `research/USER_INSTALL_171.json`에 기록한다.

## 네트워크 실행

기존 `ws` 의존성으로 독립 호스트/클라이언트 릴레이를 제공한다. `node tools/multiplayer-server.mjs`는 기본적으로 루프백의 자동 포트를 열고 호스트/클라이언트 접속 정보를 출력한다. 외부 바인딩은 `HB_NETWORK_HOST`, 고정 포트는 `HB_NETWORK_PORT`로 명시한다. 서버 시작은 설치·게임 실행만으로 자동 수행하지 않는다.

Network Session은 접속 주소·키·호스트 역할, Network Replica는 안정 네트워크 ID·소유 연결·복제 필드·보간·RPC 허용 이름·수신 이벤트를 편집한다. 접속하지 않은 월드는 소켓/재접속 타이머를 만들지 않는다. 연결 시에만 변경 상태를 최대20Hz로 전송하고, 수신 변환은 프레임에서 보간한다. 정지한 복제 상태는 반복 렌더 갱신하지 않는다. 호스트 키와 클라이언트 키를 분리하고 클라이언트의 비소유 오브젝트 변경·소유권 위조·멀티캐스트를 거부한다. RPC는 등록 대상과 허용 이벤트를 확인한 뒤 지정 수신 이벤트에 `event/sender/json`으로 전달한다. 임의 C++ 함수를 원격 실행하지 않는다.

C++/블루프린트 공용 함수는 `Network::Connect`, `Disconnect`, `SendRPC`, `SetOwner`, `GetStateText`, `HasAuthority`다. AI `runtime.network`는 연결·권한·복제 진단을 읽는다. 연결 복귀에서는 세션 ID를 유예 시간 안에 유지하고 상태를 다시 받으며, 이전 RPC를 재시도하지 않는다. 초기 상태는 묶음으로 전송한다. 기본 연결32·상태 오브젝트100000·직렬화 상태16MiB는 서버의 설정 가능한 자원 예산이다. 페이로드/전송 대기/요청 빈도를 검사한다. 상태 바이트는 JS Map/RAM/VRAM 전체 측정값이 아니다.

현재 경로는 **이미 양쪽 월드에 있는 안정 ID 오브젝트의 소유권·허용 필드 복제**다. 전용 권위 서버의 게임 규칙 실행, 액터 생성/삭제의 전체 수명 복제, 관심 영역, 예측 입력·재시뮬레이션·손실 보정, 호스트 이전·매치메이킹·플랫폼 서비스는 별도로 남는다. 클라이언트 소유 상태의 게임 규칙 검증은 호스트 게임 코드가 맡아야 한다. Unreal의 네트워크 전체나 Iris 구현과 같다고 표현하지 않는다.

## 실행 중 C++ 재적용

실행 중 C++ 빌드 버튼과 AI `native.reapply {path,dryRun?}`를 연결한다. 기존 실행은 새 바이너리를 빌드하는 동안 유지된다. 클래스·상속·기존 공개 속성 타입·함수 시그니처 호환성을 먼저 검사하고, 프레임 장벽에서 원본 코드가 바뀌지 않았는지 다시 확인한다. 공개 속성 값과 월드 변환, 블루프린트 변수·타이머를 유지하고 새 공개 속성에는 기본값을 넣는다. 새 모듈의 BeginPlay를 다시 실행하지 않는다. 레벨 준비 캐시도 새 모듈로 갱신하고 이전 worker를 해제한다. 실패한 새 모듈은 해제하며 기존 빌드를 유지한다.

비공개/정적 C++ 메모리·네이티브 타이머와 임의 포인터는 새 worker에서 재생성된다. 대규모 타입/상속 변경과 기존 함수 시그니처 변경은 재실행을 요구한다. native debugger/브레이크·스택·스레드 연결은 미완료다. Unreal Live Coding의 인프로세스 패치·Object Reinstancing과 동일한 기능으로 계산하지 않는다.

## UI·애니메이션·게임플레이

위젯 디자이너와 실행기에 TreeView와 항목별 명시 높이를 추가했다. ID/자식/깊이/전체 항목을 검증하고 펼침·접힘과 방향키·Home/End·선택을 지원한다. 높이 누적값은 데이터/펼침 변경 때 만들며 스크롤은 이진 탐색으로 보이는 행만 재사용한다. 트리 선택은 안정 `selectedItemId`, 기존 목록 선택은 인덱스를 사용한다. 실제 편집기에서1000개 자식의 트리를 펼치고 먼 위치로 스크롤해 DOM 행12개 재사용을 확인했다. 100000개 목록의 누적 높이/표시 범위도 검사했다. 내용에 따라 자동 측정하는 높이·위젯 조합/상속·월드 UI·전체 스크린리더 검증은 남는다.

리타게터 프로필은 서로 다른 모프 이름·원본/대상 메시·배율·오프셋·최소/최대를 편집한다. 모호한 동일 이름은 메시 지정을 요구한다. 대상 그래프의 기존 포즈 슬롯과 전역 Alpha를 사용하고, 보정된 모프를 골격 클립의 number 트랙으로 베이크한다. 골격과 원본 클립은 바꾸지 않는다. 프로필별 Avatar/Muscle·정지 발·접촉 보정의 전체 요구를 대체하지 않는다.

능력에는 활성/종료, 효과에는 적용/주기/제거 Cue를 추가한다. 태그와 수신 이벤트를 구조화 편집기로 작성하고 기존 능력 실행 큐로 전달한다. 여러 주기의 따라잡기는 횟수와 함께 한 이벤트로 전달한다. 실패한 능력 적용의 Cue도 함께 취소한다. 시각/음향은 수신 블루프린트/C++ 이벤트에서 기존 엔진 함수를 사용한다. 자동 VFX Cue 자산·네트워크 능력 예측/복제까지 구현한 것은 아니다.

## 월드·메시·렌더링·배포

자동 거리 셀은 World Streaming Budget의 추정 MB·셀 수·회차당 로드 수로 고른다. 우선순위·거리·안정 ID 순서로 결정하고 예산 교체 시 이전 자동 셀을 먼저 내린다. 수동/항상 로드에는 자동 예산을 적용하지 않는다. 추정 비용은 작성자가 정하는 예약값이며 프로세스 실제 메모리 제어는 아니다. 자동 공간 분할·HLOD·실측 메모리 스케줄링은 남는다.

LOD 에셋에서 표시 LOD와 별도로 충돌 레벨을 선택한다. 기존 에셋은0번을 사용하며 선택한 메시를 기존 충돌 청크 생성과 실행 물리에 전달한다. 카메라에 따른 충돌/애니메이션 LOD 전환·교차 페이드·고품질 단순화는 남는다.

UV 경계 맞추기는 겹치는3D 간선의 양쪽 UV 섬에 유사 변환을 적용한다. 위치/인덱스/분리 노멀/색을 유지하고 양 끝 UV를 맞춘다. 노멀 분할의 정점을 병합하거나 UV 선택 섬의 토폴로지를 재작성하지 않는다. 곡면 펼치기·최적 패킹·일반 seam stitch 선택/토폴로지는 별도다.

머테리얼 샘플러는 DirectX에서도 축소/확대/mip 필터를 구분하고 mip 비사용·이방성1–16을 전달한다. 선형 필터와 이방성을 함께 검증한다. 예전 샘플러 ID를 유지하고 확장 상태를 제한된 캐시에서 재사용한다. 실제 D3D11 장치에서 필터·MaxLOD·MaxAnisotropy·재사용·오류 거부를 확인했다. LOD bias·배열/볼륨 mip 생성 세부·압축 컨테이너는 남는다.

배포 패치는 파일↔폴더 전환을 지원한다. 모든 변경 파일의 백업 뒤 새 구조를 설치하고, 버전2 저널에 원래 폴더를 남긴다. 교체 오류·프로세스 강제 종료 시 검증된 출력만 제거하고 원본/빈 폴더를 복원한다. 예전 버전1 저널도 읽는다. 동시 사용자 수정은 충돌로 보존하며 실제 전원 차단·디스크 하드웨어 장애의 내구성을 완료로 계산하지 않는다.

## 대조 출처

[Unity6.0 TreeView](https://docs.unity3d.com/6000.0/Documentation/Manual/UIE-uxml-element-TreeView.html)의 계층·새로고침·가상화/포커스 구역을 읽었다. HB의 명시 높이는 Unity DynamicHeight의 자동 측정과 구별한다. [D3D11_SAMPLER_DESC](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ns-d3d11-d3d11_sampler_desc)의 필터·이방성·mip 범위를 대조했다.

[Unreal5.8 Live Coding](https://dev.epicgames.com/documentation/en-us/unreal-engine/using-live-coding-to-recompile-unreal-engine-applications-at-runtime)의 설정·모듈·Object Reinstancing 구역과 [Owner/Owning Connection](https://dev.epicgames.com/documentation/en-us/unreal-engine/actor-owner-and-owning-connection-in-unreal-engine)의 소유권/복제/RPC 관계, [RPC](https://dev.epicgames.com/documentation/unreal-engine/remote-procedure-calls-in-unreal-engine?lang=en-US)의 개요·선언 구역을 읽었다. RPC 문서 전체 표·연결 API·전체 엔진 corpus 완료로 승격하지 않는다. ProBuilder `UV_Stitch.html` 요청은 실패했으며 읽은 문서로 계산하지 않는다.


171 사용자 설치 확인: `C:/Users/kirby/HBEngine/Versions/77c55df75ff751bc`. 명세2382파일 SHA를 실행 후에도 확인했다. 설치 EXE에서 TreeView 펼침/가변 행 재사용·공개 상태 유지 C++ 재적용(1→11)/위치 보존·실제 클라이언트 상태/RPC 전달, 프리팹 자식/전체 Apply·원자 Undo, UV 사람 드래그/Undo·AI 보기의 문서 revision 보존, IK 사람 목표와 AI 뼈 설정 dryRun/추가/Undo, C++ 내비/IK/음성, Take와 믹서 편집을 확인했다. 실제 Web Audio 소스2개/가상6개, 우선순위 전환 후 소스2개·시계 오차0이었다. 장치 출력은 무음 sink를 사용했으므로 청각 음질 검증으로 계산하지 않는다. 사용자 프로필10385파일 SHA가 전후 일치했고 두 바로가기와 .hbproject 연결을 확인했다. 이전 설치187229328바이트를 정리해 Versions는1개다. [설치 근거](research/USER_INSTALL_171.json).
