# 243 · 효과 레벨·커브 제작과 실행

- 선택 실수 커브 × 기본 계수·기본 레벨1·적용 시 캡처/레벨 변경 시 재평가·지속/주기/즉시/4중첩 정책·오류 시 비용/효과 원자 복구
- 적용 때만 내용 비교하는 공유 캡처·동시 요청 합치기·64개/직렬화 추정32MiB 보관 예산·퇴출/큰 템플릿은 게임 적용 수나 기존 핸들을 제한하지 않음
- 커브/트랙/값 미리보기·Undo·실행 Inspector 레벨·공용C++4/BP/AI runtime.effect와 level·종속 SHA 검사/공동 저장/삭제 거부·일반 저장도 파일 교체 후 재검사/충돌 복구, 성공한 임시 journal 제거

검증 근거: [기계 판독 기록](research/ENGINE_WORK_243.json).

남은 범위:

- source/target 속성 캡처·SetByCaller·custom execution·네트워크 예측은 별도 잔여
- 직렬화 추정 캐시 예산은 실제 JS heap/전체 프레임 비용 상한이 아님
- C++ 쓰기는 반환 뒤 처리하고 getter는 처리된 최신 상태를 읽음


243–248 사용자 설치 e586f23febe4b3d5·2879명세 파일 실행후SHA동일·실제 숨김 editor4/독립D3D·GL게임6 오류0/exit0·효과/입자/부모Take/단축키 제작·CPP/BP/AI/Undo. User10385파일 SHA불변·링크2/.hbproject·Versions1·이전설치212367284B 제거. USER_INSTALL_248.json.
